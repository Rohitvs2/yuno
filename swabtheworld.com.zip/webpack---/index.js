module.exports = require('./lib/axios');


//////////////////
// WEBPACK FOOTER
// ./index.js
// module id = 0
// module chunks = 0