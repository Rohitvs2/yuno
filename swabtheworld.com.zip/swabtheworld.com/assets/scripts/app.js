! function() {
    "use strict";

    function a(t) {
        return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }

    function i(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function n(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
        }
    }

    function t(t, e, i) {
        return e && n(t.prototype, e), i && n(t, i), t
    }

    function s(t, e, i) {
        return e in t ? Object.defineProperty(t, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = i, t
    }

    function l(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                var i = [],
                    n = !0,
                    s = !1,
                    o = void 0;
                try {
                    for (var r, a = t[Symbol.iterator](); !(n = (r = a.next()).done) && (i.push(r.value), !e || i.length !== e); n = !0);
                } catch (t) {
                    s = !0, o = t
                } finally {
                    try {
                        n || null == a.return || a.return()
                    } finally {
                        if (s) throw o
                    }
                }
                return i
            }
        }(t, e) || o(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function c(t) {
        return function(t) {
            if (Array.isArray(t)) return r(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || o(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function o(t, e) {
        if (t) {
            if ("string" == typeof t) return r(t, e);
            var i = Object.prototype.toString.call(t).slice(8, -1);
            return "Map" === (i = "Object" === i && t.constructor ? t.constructor.name : i) || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? r(t, e) : void 0
        }
    }

    function r(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
        return n
    }
    var h = function() {
            function e(t) {
                i(this, e), this.mAttr = "data-" + t.dataName, this.mCaptureEvents = ["mouseenter", "mouseleave"], this.el = t.el
            }
            return t(e, [{
                key: "mInit",
                value: function(t) {
                    var e = this;
                    this.modules = t, this.mCheckEventTarget = this.mCheckEventTarget.bind(this), this.events && Object.keys(this.events).forEach(function(t) {
                        return e.mAddEvent(t)
                    })
                }
            }, {
                key: "mUpdate",
                value: function(t) {
                    this.modules = t
                }
            }, {
                key: "mDestroy",
                value: function() {
                    var e = this;
                    this.events && Object.keys(this.events).forEach(function(t) {
                        return e.mRemoveEvent(t)
                    })
                }
            }, {
                key: "mAddEvent",
                value: function(t) {
                    var e = !!this.mCaptureEvents.includes(t);
                    this.el.addEventListener(t, this.mCheckEventTarget, e)
                }
            }, {
                key: "mRemoveEvent",
                value: function(t) {
                    var e = !!this.mCaptureEvents.includes(t);
                    this.el.removeEventListener(t, this.mCheckEventTarget, e)
                }
            }, {
                key: "mCheckEventTarget",
                value: function(t) {
                    var e = this.events[t.type];
                    if ("string" == typeof e) this[e](t);
                    else {
                        var i = "[" + this.mAttr + "]",
                            n = t.target;
                        if (this.mCaptureEvents.includes(t.type)) n.matches(i) && this.mCallEventMethod(t, e, n);
                        else
                            for (; n && n !== document && (!n.matches(i) || "undefined" == this.mCallEventMethod(t, e, n));) n = n.parentNode
                    }
                }
            }, {
                key: "mCallEventMethod",
                value: function(t, e, i) {
                    var n = i.getAttribute(this.mAttr);
                    e.hasOwnProperty(n) && (n = e[n], t.hasOwnProperty("currentTarget") || Object.defineProperty(t, "currentTarget", {
                        value: i
                    }), t.hasOwnProperty("curTarget") || Object.defineProperty(t, "curTarget", {
                        value: i
                    }), this[n](t))
                }
            }, {
                key: "$",
                value: function(t, e) {
                    var i, n = [t.indexOf("."), t.indexOf("#"), t.indexOf("[")].filter(function(t) {
                            return -1 != t
                        }),
                        s = t,
                        o = "",
                        r = this.el;
                    return n.length && (i = Math.min.apply(Math, c(n)), s = t.slice(0, i), o = t.slice(i)), (r = "object" == a(e) ? e : r).querySelectorAll("[" + this.mAttr + "=" + s + "]" + o)
                }
            }, {
                key: "parent",
                value: function(t, e) {
                    for (var i = "[" + this.mAttr + "=" + t + "]", n = e.parentNode; n && n !== document;) {
                        if (n.matches(i)) return n;
                        n = n.parentNode
                    }
                }
            }, {
                key: "getData",
                value: function(t, e) {
                    return (e || this.el).getAttribute(this.mAttr + "-" + t)
                }
            }, {
                key: "setData",
                value: function(t, e, i) {
                    return (i || this.el).setAttribute(this.mAttr + "-" + t, e)
                }
            }, {
                key: "call",
                value: function(e, i, n, t) {
                    var s = this;
                    i && !n && (n = i, i = !1), this.modules[n] && (t ? this.modules[n][t] && this.modules[n][t][e](i) : Object.keys(this.modules[n]).forEach(function(t) {
                        s.modules[n][t][e](i)
                    }))
                }
            }, {
                key: "on",
                value: function(e, i, n, t) {
                    var s = this;
                    this.modules[i] && (t ? this.modules[i][t].el.addEventListener(e, function(t) {
                        return n(t)
                    }) : Object.keys(this.modules[i]).forEach(function(t) {
                        s.modules[i][t].el.addEventListener(e, function(t) {
                            return n(t)
                        })
                    }))
                }
            }, {
                key: "init",
                value: function() {}
            }, {
                key: "destroy",
                value: function() {}
            }]), e
        }(),
        e = function() {
            function e(t) {
                i(this, e), this.app, this.modules = t.modules, this.currentModules = {}, this.activeModules = {}, this.newModules = {}, this.moduleId = 0
            }
            return t(e, [{
                key: "init",
                value: function(t, o) {
                    var r = this,
                        e = (o || document).querySelectorAll("*");
                    t && !this.app && (this.app = t), this.activeModules.app = {
                        app: this.app
                    }, e.forEach(function(s) {
                        Array.from(s.attributes).forEach(function(t) {
                            var e, i, n;
                            t.name.startsWith("data-module") && (n = !1, i = t.name.split("-").splice(2), e = r.toCamel(i), r.modules[e] ? n = !0 : r.modules[r.toUpper(e)] && (e = r.toUpper(e), n = !0), n && (n = {
                                el: s,
                                name: e,
                                dataName: i.join("-")
                            }, i = new r.modules[e](n), (n = t.value) || (r.moduleId++, n = "m" + r.moduleId, s.setAttribute(t.name, n)), r.addActiveModule(e, n, i), n = e + "-" + n, o ? r.newModules[n] = i : r.currentModules[n] = i))
                        })
                    }), Object.entries(this.currentModules).forEach(function(t) {
                        var e = l(t, 2),
                            i = e[0],
                            t = e[1];
                        o ? (i = (e = i.split("-")).shift(), e = e.pop(), r.addActiveModule(i, e, t)) : r.initModule(t)
                    })
                }
            }, {
                key: "initModule",
                value: function(t) {
                    t.mInit(this.activeModules), t.init()
                }
            }, {
                key: "addActiveModule",
                value: function(t, e, i) {
                    this.activeModules[t] ? Object.assign(this.activeModules[t], s({}, e, i)) : this.activeModules[t] = s({}, e, i)
                }
            }, {
                key: "update",
                value: function(t) {
                    var e = this;
                    this.init(this.app, t), Object.entries(this.currentModules).forEach(function(t) {
                        t = l(t, 2);
                        t[0], t[1].mUpdate(e.activeModules)
                    }), Object.entries(this.newModules).forEach(function(t) {
                        t = l(t, 2);
                        t[0];
                        t = t[1];
                        e.initModule(t)
                    }), Object.assign(this.currentModules, this.newModules)
                }
            }, {
                key: "destroy",
                value: function(t) {
                    t ? this.destroyScope(t) : this.destroyModules()
                }
            }, {
                key: "destroyScope",
                value: function(t) {
                    var i = this;
                    t.querySelectorAll("*").forEach(function(t) {
                        Array.from(t.attributes).forEach(function(t) {
                            var e;
                            t.name.startsWith("data-module") && (e = t.value, t = t.name.split("-").splice(2), t = i.toCamel(t) + "-" + e, e = !1, i.currentModules[t] ? e = !0 : i.currentModules[i.toUpper(t)] && (t = i.toUpper(t), e = !0), e && (i.destroyModule(i.currentModules[t]), delete i.currentModules[t]))
                        })
                    }), this.activeModules = {}, this.newModules = {}
                }
            }, {
                key: "destroyModules",
                value: function() {
                    var e = this;
                    Object.entries(this.currentModules).forEach(function(t) {
                        t = l(t, 2);
                        t[0];
                        t = t[1];
                        e.destroyModule(t)
                    }), this.currentModules = []
                }
            }, {
                key: "destroyModule",
                value: function(t) {
                    t.mDestroy(), t.destroy()
                }
            }, {
                key: "toCamel",
                value: function(t) {
                    var i = this;
                    return t.reduce(function(t, e) {
                        return t + i.toUpper(e)
                    })
                }
            }, {
                key: "toUpper",
                value: function(t) {
                    return t.charAt(0).toUpperCase() + t.slice(1)
                }
            }]), e
        }();

    function u(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function d(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
        }
    }

    function f(t, e, i) {
        return e && d(t.prototype, e), i && d(t, i), t
    }

    function p(t, e) {
        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
        t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                writable: !0,
                configurable: !0
            }
        }), e && y(t, e)
    }

    function m(t) {
        return (m = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
            return t.__proto__ || Object.getPrototypeOf(t)
        })(t)
    }

    function y(t, e) {
        return (y = Object.setPrototypeOf || function(t, e) {
            return t.__proto__ = e, t
        })(t, e)
    }

    function v(t) {
        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return t
    }

    function g(i) {
        var n = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
            } catch (t) {
                return !1
            }
        }();
        return function() {
            var t, e = m(i);
            return function(t, e) {
                if (e && ("object" == typeof e || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return v(t)
            }(this, n ? (t = m(this).constructor, Reflect.construct(e, arguments, t)) : e.apply(this, arguments))
        }
    }

    function w(t, e, i) {
        return (w = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, i) {
            t = function(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = m(t)););
                return t
            }(t, e);
            if (t) {
                e = Object.getOwnPropertyDescriptor(t, e);
                return e.get ? e.get.call(i) : e.value
            }
        })(t, e, i || t)
    }

    function b(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
        return n
    }

    function k(t, e) {
        var i = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
        if (!i) {
            if (Array.isArray(t) || (i = function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return b(t, e);
                        var i = Object.prototype.toString.call(t).slice(8, -1);
                        return "Map" === (i = "Object" === i && t.constructor ? t.constructor.name : i) || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? b(t, e) : void 0
                    }
                }(t)) || e && t && "number" == typeof t.length) {
                i && (t = i);
                var n = 0,
                    e = function() {};
                return {
                    s: e,
                    n: function() {
                        return n >= t.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: t[n++]
                        }
                    },
                    e: function(t) {
                        throw t
                    },
                    f: e
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var s, o = !0,
            r = !1;
        return {
            s: function() {
                i = i.call(t)
            },
            n: function() {
                var t = i.next();
                return o = t.done, t
            },
            e: function(t) {
                r = !0, s = t
            },
            f: function() {
                try {
                    o || null == i.return || i.return()
                } finally {
                    if (r) throw s
                }
            }
        }
    }
    var E = "Swab The World";
    $(document);
    var T = $(window),
        S = document.documentElement,
        x = $(document.documentElement).removeClass("has-no-js").addClass("has-js");
    $(document.body), $("#js-pjax-wrapper"), x.data("debug");
    var C = ".js-accordion-item",
        A = ".js-accordion-content",
        O = "is-open",
        L = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        triggerer: "trigger"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "trigger",
                value: function(t) {
                    t = t.curTarget.closest(C);
                    t.classList.contains(O) ? this.close(t) : this.open(t)
                }
            }, {
                key: "open",
                value: function(t) {
                    var e = this;
                    this.checkActive(), $(t.querySelector(A)).slideDown(300, function() {
                        return e.scrollTo(t)
                    }), t.classList.add(O)
                }
            }, {
                key: "close",
                value: function(t) {
                    var e = this;
                    $(t.querySelector(A)).slideUp(300, function() {
                        e.call("update", null, "scroll", "main")
                    }), t.classList.remove(O)
                }
            }, {
                key: "checkActive",
                value: function() {
                    var t = this.el.querySelector(C + "." + O);
                    null != t && this.close(t)
                }
            }, {
                key: "scrollTo",
                value: function(t) {
                    this.call("update", null, "scroll", "main"), this.call("scrollTo", t, "scroll", "main")
                }
            }]), i
        }(),
        M = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    window.isMobile || (this.initTween(), this.computeData(), this.update())
                }
            }, {
                key: "initTween",
                value: function() {
                    this.tween = new TimelineMax, this.tween.from(this.el, 1, {
                        scaleX: 0,
                        force3D: !0
                    }), this.tween.pause()
                }
            }, {
                key: "computeData",
                value: function() {
                    this.boundaries = this.el.getBoundingClientRect()
                }
            }, {
                key: "update",
                value: function() {
                    var t = 100 * window.scrollObj.scroll.y / this.boundaries.height / 100 * 2;
                    t <= 1 && 0 <= t && this.tween.progress(t).play().pause(), 1 < t && this.tween.progress(1).play().pause(), this.raf = requestAnimationFrame(this.update.bind(this))
                }
            }, {
                key: "destroy",
                value: function() {
                    this.raf && cancelAnimationFrame(this.raf), this.tween && this.tween.kill && this.tween.kill()
                }
            }]), i
        }(),
        I = {
            slidesPerView: 1,
            speed: 850,
            spaceBetween: 40,
            grabCursor: !0,
            autoplay: {
                delay: 3e3
            },
            pagination: {
                el: ".swiper-pagination",
                type: "bullets",
                clickable: !0
            }
        },
        P = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var t = this;
                    this.slides = Array.from(this.$("slide")), this.call("initCount", this.slides.length, "carouselheadercount"), this.carousel = new Swiper(this.$("carousel")[0], I), this.carousel.on("slideChange", function() {
                        t.call("slideTo", t.carousel.realIndex, "carouselheadercount"), t.call("slideTo", t.carousel.realIndex, "carouselheadertext"), t.carousel.realIndex === t.slides.length - 1 && (t.carousel.autoplay.pause(), setTimeout(function() {
                            t.carousel.autoplay.pause(0)
                        }, 3e3))
                    })
                }
            }, {
                key: "destroy",
                value: function() {
                    this.carousel.destroy(!0, !0), this.carousel.off("slideChange")
                }
            }]), i
        }(),
        D = {
            speed: 600,
            direction: "vertical",
            slidesPerView: "1",
            simulateTouch: !1,
            allowTouchMove: !1
        },
        j = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "initCount",
                value: function(t) {
                    for (var e = 0; e < t; e++) {
                        var i = document.createElement("span");
                        i.classList.add("swiper-slide", "c-carousel-header-count_slide"), i.innerHTML = e + 1, this.$("wrapper")[0].appendChild(i)
                    }
                    this.$("total")[0].innerHTML = t, this.carousel = new Swiper(this.$("carousel")[0], D)
                }
            }, {
                key: "slideTo",
                value: function(t) {
                    this.carousel && this.carousel.slideTo && this.carousel.slideTo(t)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.carousel && this.carousel.destroy && this.carousel.destroy(!0, !0)
                }
            }]), i
        }(),
        B = {
            speed: 600,
            slidesPerView: "1",
            simulateTouch: !1,
            allowTouchMove: !1,
            spaceBetween: 20
        },
        H = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.carousel = new Swiper(this.el, B)
                }
            }, {
                key: "slideTo",
                value: function(t) {
                    this.carousel && this.carousel.slideTo && this.carousel.slideTo(t)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.carousel && this.carousel.destroy && this.carousel.destroy(!0, !0)
                }
            }]), i
        }(),
        _ = ".js-carousel",
        R = ".js-slide",
        F = ".js-pagination",
        W = ".js-pagination-item",
        q = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var t = this;
                    this.initPagination(), this.carousel = new Swiper(this.el.querySelector(_), {
                        speed: 600,
                        spaceBetween: 100,
                        touchStartPreventDefault: !1,
                        grabCursor: !0
                    }), this.carousel.on("slideChange", function() {
                        return t.updatePagination(t.carousel.realIndex)
                    }), this.updatePagination(this.carousel.realIndex)
                }
            }, {
                key: "initPagination",
                value: function() {
                    var e = this;
                    this.slidesCount = this.el.querySelectorAll(R).length, this.pagination = this.el.querySelector(F);
                    for (var t = 0; t <= this.slidesCount - 1; t++) {
                        var i = (new DOMParser).parseFromString('<span class="c-carousel-number_pagination_item js-pagination-item" data-index="'.concat(t, '">').concat(t + 1, "</span>"), "text/html");
                        this.el.querySelector(F).appendChild(i.body.firstChild)
                    }
                    this.paginationBind = this.goTo.bind(this), this.paginationItems = Array.from(this.el.querySelectorAll(W)), this.paginationItems.forEach(function(t) {
                        t.addEventListener("click", e.paginationBind)
                    })
                }
            }, {
                key: "updatePagination",
                value: function(t) {
                    Array.from(this.el.querySelectorAll(W), function(t) {
                        t.classList.remove("is-active")
                    }), this.pagination.querySelector('[data-index="'.concat(t, '"]')).classList.add("is-active")
                }
            }, {
                key: "goTo",
                value: function(t) {
                    t = t.target.innerText - 1;
                    this.carousel.slideTo(t), this.updatePagination(t)
                }
            }, {
                key: "destroy",
                value: function() {
                    var e = this;
                    this.carousel.destroy(!0, !0), this.paginationItems.forEach(function(t) {
                        t.removeEventListener("click", e.paginationBind)
                    })
                }
            }]), i
        }(),
        z = ".js-carousel",
        Y = ".js-pagination",
        U = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.carousel = new Swiper(this.el.querySelector(z), {
                        speed: 600,
                        spaceBetween: 100,
                        touchStartPreventDefault: !1,
                        grabCursor: !0,
                        pagination: {
                            clickable: !0,
                            el: Y
                        }
                    })
                }
            }, {
                key: "goTo",
                value: function(t) {
                    t = t.target.innerText - 1;
                    this.carousel.slideTo(t)
                }
            }, {
                key: "startAutoPlay",
                value: function() {
                    this.carousel.autoplay.start()
                }
            }, {
                key: "destroy",
                value: function() {
                    this.carousel.destroy(!0, !0)
                }
            }]), i
        }(),
        N = ["94,98,209", "60,109,121", "220,133,106", "255,209,150"],
        V = [.75, 1, .75, 1, .75, 1, .75, 1, .75],
        X = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.initChart()
                }
            }, {
                key: "initChart",
                value: function() {
                    this.canvas = this.el.querySelector("canvas"), this.ctx = this.canvas.getContext("2d"), this.isLanding = this.el.dataset.isLanding, this.dataLabels = this.el.getAttribute("data-labels").split(",");
                    var t = {
                        type: "doughnut",
                        data: {
                            datasets: [{
                                data: this.isLanding ? [70.1, 15.2, 4.8, 4.8, 2.7, 2.3, 1.4, 1, .9, .4, .4, .4] : [70.1, 15.2, 1.4, 1.3, 1, .9, .4, .4],
                                backgroundColor: this.isLanding ? ["#c9c9dd", "#acadd2", "#8586be", "#5f62aa", "#d5826c", "#dae891", "white", "#3c6c76", "#63a276", "#e9ac74", "#7bc8bb"] : ["white", "white", "white", "white", "white", "white", "white", "white"],
                                borderWidth: 0
                            }],
                            labels: this.dataLabels
                        },
                        options: {
                            circumference: Math.PI,
                            rotation: -Math.PI,
                            legend: {
                                display: !1
                            },
                            tooltips: {
                                displayColors: !1,
                                caretSize: 0,
                                cornerRadius: 0,
                                backgroundColor: "rgba(0, 0, 0, 0.4)",
                                position: "nearest",
                                callbacks: {
                                    label: function(t, e) {
                                        return e.labels[t.index] + ": " + e.datasets[0].data[t.index] + "%"
                                    }
                                }
                            },
                            hover: {
                                mode: "nearest"
                            }
                        }
                    };
                    this.chart = new Chart(this.ctx, t), this.setChartColor()
                }
            }, {
                key: "setChartColor",
                value: function(n) {
                    var s = this;
                    void 0 !== n && (Array.from(this.chart.data.datasets[0].data).forEach(function(t, e) {
                        var i = V[e];
                        s.chart.data.datasets[0].backgroundColor[e] = "rgba(".concat(N[n], ",").concat(i, ")"), Object.assign(s.chart.options.tooltips, {
                            displayColors: !1,
                            caretSize: 0,
                            cornerRadius: 0,
                            backgroundColor: "rgba(".concat(N[n], ",1)")
                        })
                    }), this.chart.update(0))
                }
            }]), i
        }(),
        K = ["aloes-lavender", "mango-whale", "lime-rhubarb", "leaf-peach"],
        Z = ".js-update-colorset",
        G = ".js-chart",
        J = "is-hidden",
        Q = "-hide-native",
        tt = "is-playing",
        et = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).currentIndex = 0, t.maxIndex = K.length, t.isPlaying = !0, t.currentPortrait = 1, t.events = {
                    click: "toggle"
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.cursorZoneEl = this.el, this.chartEl = this.el.querySelector(G), this.updateEl = this.el.querySelectorAll(Z), this.mouseenterBind = this.hover.bind(this), this.mouseleaveBind = this.leave.bind(this), null != this.chartEl && (this.chartEl.addEventListener("mouseenter", this.mouseenterBind), this.chartEl.addEventListener("mouseleave", this.mouseleaveBind)), this.play()
                }
            }, {
                key: "toggle",
                value: function() {
                    this.isPlaying ? (this.isPlaying = !1, this.pause()) : (this.isPlaying = !0, this.play())
                }
            }, {
                key: "play",
                value: function() {
                    var t = this;
                    this.updater = setInterval(function() {
                        t.currentIndex == t.maxIndex && (t.currentIndex = 0), t.updateColor(t.currentIndex), t.currentIndex++
                    }, 1e3), this.cursorZoneEl.classList.add(tt)
                }
            }, {
                key: "pause",
                value: function() {
                    clearInterval(this.updater), this.updater = null, this.cursorZoneEl.classList.remove(tt)
                }
            }, {
                key: "hover",
                value: function() {
                    this.cursorZoneEl.classList.add(J), this.cursorZoneEl.classList.remove(Q), this.isPlaying && this.pause()
                }
            }, {
                key: "leave",
                value: function() {
                    this.cursorZoneEl.classList.remove(J), this.cursorZoneEl.classList.add(Q), this.isPlaying && this.play()
                }
            }, {
                key: "updateColor",
                value: function(e) {
                    Array.from(this.updateEl).forEach(function(t) {
                        t.setAttribute("data-colorset", K[e])
                    }), null != this.chartEl && this.call("setChartColor", e, "chart")
                }
            }, {
                key: "destroy",
                value: function() {
                    clearInterval(this.updater), null != this.chartEl && (this.chartEl.removeEventListener("mouseenter", this.mouseenterBind), this.chartEl.removeEventListener("mouseleave", this.mouseleaveBind))
                }
            }]), i
        }(),
        it = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var t = this;
                    window.localStorage.getItem("swab-consent-form") || (this.el.classList.add("is-visible"), this.consentBind = function() {
                        t.el.classList.remove("is-visible"), window.localStorage.setItem("swab-consent-form", "dismissed")
                    }, this.$("button")[0].addEventListener("click", this.consentBind))
                }
            }, {
                key: "destroy",
                value: function() {
                    this.consentBind && this.$("button")[0].removeEventListener("click", this.consentBind)
                }
            }]), i
        }();

    function nt(t, e, i) {
        return (1 - i) * t + i * e
    }
    var st = "".concat(E, ".").concat("CursorZone"),
        ot = {
            CLICK: "click.".concat(st),
            MOUSEENTER: "mouseenter.".concat(st),
            MOUSELEAVE: "mouseleave.".concat(st),
            MOUSEMOVE: "mousemove.".concat(st),
            MOUSEDOWN: "mousedown.".concat(st),
            MOUSEUP: "mouseup.".concat(st),
            TOUCHSTART: "touchstart.".concat(st),
            TOUCHEND: "touchend.".concat(st),
            SET_TIMEOUT_DURATION: "setTimeoutDuration.".concat(st),
            SET_TEXT: "setText.".concat(st),
            RESIZE: "resize.".concat(st)
        },
        rt = "has-cursor-hover",
        at = "is-dragging",
        lt = function() {
            p(n, h);
            var i = g(n);

            function n(t) {
                u(this, n);
                var e, t = {
                    draggable: (e = i.call(this, t)).getData("draggable"),
                    "timeout-duration": e.getData("timeout-duration")
                };
                return e.log = t.log, e.$el = $(e.el), e.$cursor = $(".js-cursor", e.$el), e.$span = e.$cursor.find("span"), e.isHover = !1, e.isOverNoHover = !1, e.hideCursor = !1, e.touch = !1, e.draggable = t.draggable || !1, e.timeoutDuration = t["timeout-duration"] || !1, e.mouse = {
                    x: window.innerWidth / 2,
                    y: window.innerHeight / 2
                }, e.realMouse = {
                    x: 0,
                    y: 0
                }, e.lastRealMouse = {
                    x: 0,
                    y: 0
                }, e
            }
            return f(n, [{
                key: "init",
                value: function() {
                    var e = this;
                    window.isMobile || (this.compute(), this.manageResize(), window.isMobile || (this.$el.on(ot.MOUSELEAVE, ".js-no-drag, a:not(.js-hover), iframe", function() {
                        e.touch || (e.isOverNoHover = !1)
                    }), this.$el.on(ot.MOUSEENTER, ".js-no-drag, a:not(.js-hover), iframe", function() {
                        e.touch || (e.isOverNoHover = !0)
                    }), this.$el.on(ot.TOUCHSTART, function() {
                        e.touch = !0
                    }), this.$el.on(ot.TOUCHEND, function() {
                        e.touch = !1
                    }), this.$el.on(ot.MOUSEUP, ".js-drag-zone", function() {
                        return e.mouseup()
                    }), this.$el.on(ot.MOUSEDOWN, ".js-drag-zone", function(t) {
                        return e.mousedown()
                    }), this.$el.on(ot.SET_TEXT, function(t) {
                        return e.setText(t.options.value)
                    }), this.$el.on(ot.SET_TIMEOUT_DURATION, function(t) {
                        return e.setTimeoutDuration(t.options.value)
                    }), this.animate()))
                }
            }, {
                key: "animate",
                value: function() {
                    this.realMouse = {
                        x: window.cursor.x - this.offsetLeft,
                        y: window.cursor.y - (this.offsetTop - window.scrollObj.scroll.y)
                    }, window.touch ? this.isHover = !1 : this.isHover = 0 <= this.realMouse.x && this.realMouse.x <= this.clientWidth && 0 <= this.realMouse.y && this.realMouse.y <= this.clientHeight, !this.timeoutDuration || window.touch || this.realMouse.x == this.lastRealMouse.x && this.realMouse.y == this.lastRealMouse.y || this.setTimeoutDuration(this.timeoutDuration), this.$el.toggleClass(rt, this.isHover && !this.hideCursor && !this.isOverNoHover), this.isHover && !window.touch && (this.mouse.x = nt(this.mouse.x, this.realMouse.x, .2), this.mouse.y = nt(this.mouse.y, this.realMouse.y, .2), this.$cursor.css({
                        "-webkit-transform": "translate3d(".concat(this.mouse.x, "px, ").concat(this.mouse.y, "px, 0px)"),
                        "-ms-transform": "translate3d(".concat(this.mouse.x, "px, ").concat(this.mouse.y, "px, 0px)"),
                        transform: "translate3d(".concat(this.mouse.x, "px, ").concat(this.mouse.y, "px, 0px)")
                    })), this.lastRealMouse = {
                        x: parseFloat(this.realMouse.x),
                        y: parseFloat(this.realMouse.y)
                    }, this.raf = requestAnimationFrame(this.animate.bind(this))
                }
            }, {
                key: "manageResize",
                value: function() {
                    var t = this,
                        e = !1;
                    this.resizeCheckBind = function() {
                        e || (requestAnimationFrame(function() {
                            t.compute(), e = !1
                        }), e = !0)
                    }, T.on(ot.RESIZE, this.resizeCheckBind)
                }
            }, {
                key: "compute",
                value: function() {
                    this.clientWidth = this.el.clientWidth, this.clientHeight = this.el.clientHeight, this.offsetTop = this.$el.offset().top + window.scrollObj.scroll.y, this.offsetLeft = this.$el.offset().left, this.log && console.log(this.offsetTop, this.el)
                }
            }, {
                key: "mousedown",
                value: function() {
                    this.draggable && this.$el.addClass(at)
                }
            }, {
                key: "mouseup",
                value: function() {
                    this.draggable && this.$el.removeClass(at)
                }
            }, {
                key: "setTimeoutDuration",
                value: function(t) {
                    this.hideCursor = !1, window.isMobile && this.$el.toggleClass(rt, !0), this.timeoutDuration = t, this.resetTimeout()
                }
            }, {
                key: "resetTimeout",
                value: function() {
                    var t = this;
                    clearTimeout(this.timeout), this.timeoutDuration && this.isHover && (this.timeout = setTimeout(function() {
                        t.hideCursor = !0, window.isMobile && t.$el.toggleClass(rt, !1)
                    }, this.timeoutDuration))
                }
            }, {
                key: "setText",
                value: function(t) {
                    var e = this;
                    this.textTl && this.textTl.kill && this.textTl.kill(), this.textTl = new TimelineMax, this.textTl.to(this.$span, .25, {
                        opacity: 0
                    }), this.textTl.addCallback(function() {
                        e.$span.text(t)
                    }), this.textTl.to(this.$span, .25, {
                        opacity: 1
                    })
                }
            }, {
                key: "destroy",
                value: function() {
                    window.isMobile || (this.$el.off(".".concat(st)), cancelAnimationFrame(this.raf), T.off(ot.RESIZE, this.resizeCheckBind), this.$el.off(".".concat(st)), T.off(".".concat(st)))
                }
            }]), n
        }(),
        ct = ".js-total",
        ht = ".js-item-custom",
        ut = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        item: "updateTotal",
                        total: "setToCustom"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var e = this;
                    this.elTotal = this.el.querySelector(ct), Array.from(this.$("item")).map(function(t) {
                        t.checked && (e.elTotal.value = t.value)
                    }), this.totalBind = this.clearTotal.bind(this), this.elTotal.addEventListener("focus", this.totalBind)
                }
            }, {
                key: "updateTotal",
                value: function(t) {
                    t = t.curTarget.value;
                    "custom" != t ? this.elTotal.value = t : (this.elTotal.value = "", this.elTotal.focus())
                }
            }, {
                key: "clearTotal",
                value: function() {
                    this.elTotal.value = ""
                }
            }, {
                key: "setToCustom",
                value: function() {
                    this.el.querySelector(ht).checked = !0
                }
            }, {
                key: "destroy",
                value: function() {
                    this.elTotal.removeEventListener("focus", this.totalBind)
                }
            }]), i
        }(),
        dt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    change: {
                        select: "update"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.items = this.$("item"), this.path = this.el.getAttribute("data-path");
                    var t = document.getElementById("categorySelector"),
                        e = document.getElementById("label"),
                        t = t.options[t.selectedIndex].text;
                    e.innerHTML = t
                }
            }, {
                key: "update",
                value: function(t) {
                    var e = t.currentTarget,
                        i = this.parent("item", e);
                    this.$("label", i)[0].innerHTML = Array.from(e.options).find(function(t) {
                        return t.value == e.value
                    }).innerHTML;
                    t = document.getElementById("categorySelector"), i = t.options[t.selectedIndex].value, i = 0 == t.selectedIndex ? "" : "&category=" + i, i = this.path + i + "#articles";
                    this.call("goTo", i, "load")
                }
            }]), i
        }(),
        ft = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    change: {
                        selectCountry: "updateCountry",
                        selectEthnicity: "updateEthnicity"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.items = this.$("item"), this.countryPath = this.el.getAttribute("data-country-path"), this.ethnicityPath = this.el.getAttribute("data-ethnicity-path"), this.ethnicityId = this.el.getAttribute("data-ethnicity-id"), this.updateCountry(null, this.el.querySelector("#countrySelector")), this.updateEthnicity(null, this.el.querySelector("#ethnicitySelector"))
                }
            }, {
                key: "updateCountry",
                value: function(t) {
                    var e = t ? t.curTarget : 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null,
                        i = this.parent("item", e),
                        n = this.$("label", i),
                        i = Array.from(e.options).find(function(t) {
                            return t.value == e.value
                        }).innerHTML;
                    console.log(i), i && (n[0].innerHTML = i);
                    i = document.getElementById("countrySelector"), i = i.options[i.selectedIndex].value || 0;
                    t && this.call("goTo", this.countryPath + i + this.ethnicityId + "#patients", "load")
                }
            }, {
                key: "updateEthnicity",
                value: function(t) {
                    var e = t ? t.curTarget : 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null,
                        i = this.parent("item", e),
                        n = this.$("label", i),
                        i = Array.from(e.options).find(function(t) {
                            return t.value == e.value
                        }).innerHTML;
                    i && (n[0].innerHTML = i);
                    i = document.getElementById("ethnicitySelector"), i = i.options[i.selectedIndex].value || 0;
                    t && this.call("goTo", this.ethnicityPath + i + "#patients", "load")
                }
            }]), i
        }(),
        pt = "is-error",
        mt = "is-success",
        yt = "is-submitting",
        vt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        button: "submit"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "submit",
                value: function(t) {
                    t.preventDefault(), this.validate(), this.clearState(), this.isLoading()
                }
            }, {
                key: "isLoading",
                value: function() {
                    var t = this;
                    this.el.classList.add(yt), setTimeout(function() {
                        t.isSuccess()
                    }, 2e3)
                }
            }, {
                key: "isSuccess",
                value: function() {
                    this.el.classList.remove(yt), this.el.classList.add(mt), this.el.reset()
                }
            }, {
                key: "isError",
                value: function(t) {
                    t.classList.add(pt)
                }
            }, {
                key: "validate",
                value: function() {}
            }, {
                key: "clearState",
                value: function() {
                    this.el.classList.remove(yt), this.el.classList.remove(mt), this.el.classList.remove(pt)
                }
            }]), i
        }(),
        gt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var i = this;
                    this.recaptcha = this.el.dataset.recaptcha || !1, this.recaptcha && (this.action = this.el.action, this.success = this.el.dataset.success, this.error = this.el.dataset.error, this.messagesWrapper = this.el.querySelector(".o-form_confirmation"), this.handlers = {
                        submit: function(t) {
                            return t.preventDefault(), i.el.classList.remove("is-success"), i.el.classList.remove("is-error"), i.messagesWrapper.innerHTML = "", grecaptcha.ready(function() {
                                return grecaptcha.execute(i.recaptcha, {
                                    action: "submit"
                                }).then(function(t) {
                                    var e = new FormData(i.el);
                                    return e.append("token", t), fetch(i.action, {
                                        method: "POST",
                                        body: e
                                    }).then(function(t) {
                                        if (!t.ok) throw new Error(t.statusText);
                                        return t
                                    })
                                }).then(function(t) {
                                    return i.el.classList.add("is-success"), i.messagesWrapper.innerHTML = i.success, t
                                }).catch(function(t) {
                                    throw i.el.classList.add("is-error"), i.messagesWrapper.innerHTML = i.error, t
                                })
                            }), !1
                        }
                    }, this.el.addEventListener("submit", this.handlers.submit))
                }
            }, {
                key: "destroy",
                value: function() {
                    this.recaptcha && this.el.removeEventListener("submit", this.handlers.submit)
                }
            }]), i
        }(),
        wt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.initPayment(), this.initAddress()
                }
            }, {
                key: "initPayment",
                value: function() {
                    var e = this;
                    this.busy = !1, this.form = document.getElementById("donation-form"), this.form_btn = document.getElementById("donation-form-button"), this.error_box = document.getElementById("error-box");
                    var t = {
                        mask: Date,
                        pattern: "m/YYYY",
                        YYYY: {
                            mask: IMask.MaskedRange,
                            from: 2020,
                            to: 9999
                        }
                    };
                    this.credit_mask = IMask(document.getElementById("CHECKOUT-CARD-NUMBER"), {
                        mask: "0000 0000 0000 0000"
                    }), this.cvc_mask = IMask(document.getElementById("CHECKOUT-CVC"), {
                        mask: "000"
                    }), this.expiration_mask = IMask(document.getElementById("CHECKOUT-EXPIRATION"), t), this.paymentBind = function(t) {
                        if (t.preventDefault(), e.busy) return !1;
                        e.busy = !0, e.createPayment().then(function(t) {
                            t = t.data;
                            document.getElementById("donation-reference").value = t, e.form.setAttribute("action", "/actions/project-module/commerce/confirmation"), e.form.submit()
                        }).catch(function(t) {
                            e.error_box.style.display = "block", e.busy = !1, requestAnimationFrame(function() {
                                e.call("update", null, "scroll", "main")
                            })
                        })
                    }, this.form_btn.addEventListener("click", this.paymentBind)
                }
            }, {
                key: "createPayment",
                value: function() {
                    var c = this;
                    return new Promise(function(e, i) {
                        var t = c.credit_mask.unmaskedValue,
                            n = c.expiration_mask.value,
                            s = c.cvc_mask.unmaskedValue,
                            o = document.querySelector('input[name="amount"]').value,
                            r = document.getElementById("CHECKOUT-SHIPPING-COUNTRY").value,
                            a = document.getElementById("email").value,
                            l = new FormData;
                        l.append("number", t), l.append("expiration", n), l.append("cvc", s), l.append("amount", o), l.append("countryId", r), l.append("email", a), axios({
                            method: "post",
                            url: "/actions/project-module/commerce/create-payment",
                            data: l
                        }).then(function(t) {
                            e(t)
                        }).catch(function(t) {
                            i(t)
                        })
                    })
                }
            }, {
                key: "initAddress",
                value: function() {
                    this.countryField = document.getElementById("CHECKOUT-SHIPPING-COUNTRY"), this.addressFieldContainer = document.getElementById("CHECKOUT-SHIPPING-ADDRESS-1-container"), this.addressBind = this.showHideAddressField.bind(this), this.countryField.addEventListener("change", this.addressBind), this.showHideAddressField()
                }
            }, {
                key: "showHideAddressField",
                value: function() {
                    var t = this,
                        e = this.countryField.value;
                    this.addressFieldContainer.style.display = "CA" === e ? "block" : "none", requestAnimationFrame(function() {
                        t.call("update", null, "scroll", "main")
                    })
                }
            }, {
                key: "destroy",
                value: function() {
                    this.countryField.removeEventListener("change", this.addressBind), this.form_btn.removeEventListener("click", this.paymentBind)
                }
            }]), i
        }(),
        bt = ".js-avatar-input",
        kt = ".js-avatar-option",
        Et = "is-active",
        Tt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        item: "updateAvatar"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "updateAvatar",
                value: function(t) {
                    var e, i = t.curTarget,
                        t = i.getAttribute("data-profile-avatar"),
                        n = k(this.el.querySelectorAll(kt));
                    try {
                        for (n.s(); !(e = n.n()).done;) e.value.classList.remove(Et)
                    } catch (t) {
                        n.e(t)
                    } finally {
                        n.f()
                    }
                    i.classList.add(Et), this.el.querySelector(bt).value = t
                }
            }]), i
        }(),
        St = ".js-filepond-banner-picture",
        xt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    "" === this.getData("default-image") ? this.defaultImage = !1 : this.defaultImage = this.getData("default-image"), this.initFilepond()
                }
            }, {
                key: "initFilepond",
                value: function() {
                    FilePond.registerPlugin(FilePondPluginFileValidateSize, FilePondPluginFileValidateType), this.pondInput = this.el.querySelector(St), this.pond = FilePond.create(this.pondInput, {
                        allowMultiple: !1,
                        labelIdle: 'Drag & Drop File<span class="filepond--label-action">Browse Files</span>',
                        allowFileSizeValidation: !0,
                        maxFileSize: "12MB",
                        allowImagePreview: !1
                    }), this.defaultImage && this.pond.addFile(this.defaultImage)
                }
            }, {
                key: "destroy",
                value: function() {
                    FilePond.destroy(this.el.querySelector(St))
                }
            }]), i
        }(),
        Ct = ".js-color-input",
        At = ".js-color-option",
        Ot = "is-active",
        Lt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        item: "updateColors"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "updateColors",
                value: function(t) {
                    var e, i = t.curTarget,
                        t = i.getAttribute("data-profile-colorset"),
                        n = k(this.el.querySelectorAll(At));
                    try {
                        for (n.s(); !(e = n.n()).done;) e.value.classList.remove(Ot)
                    } catch (t) {
                        n.e(t)
                    } finally {
                        n.f()
                    }
                    i.classList.add(Ot), this.el.querySelector(Ct).value = t
                }
            }]), i
        }(),
        Mt = ".js-filepond-media",
        It = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    "" === this.getData("default-images") ? this.defaultImages = !1 : this.defaultImages = this.getData("default-images").split(","), this.initFilepond()
                }
            }, {
                key: "initFilepond",
                value: function() {
                    var t = this;
                    FilePond.registerPlugin(FilePondPluginFileValidateSize, FilePondPluginFileValidateType), this.pondInput = this.el.querySelector(Mt), this.pond = FilePond.create(this.pondInput, {
                        allowMultiple: !0,
                        maxFiles: 3,
                        labelIdle: 'Drag & Drop Files<span class="filepond--label-action">Browse Files</span>',
                        maxFileSize: "12MB",
                        acceptedFileTypes: ["image/png", "image/jpeg"]
                    }), this.updateFilesBind = function() {
                        setTimeout(function() {
                            t.call("update", null, "scroll")
                        }, 500)
                    }, this.pond.on("updatefiles", this.updateFilesBind), this.defaultImages && this.pond.addFiles(this.defaultImages)
                }
            }, {
                key: "destroy",
                value: function() {
                    FilePond.destroy(this.el.querySelector(Mt)), this.pond.off("updatefiles", this.updateFilesBind)
                }
            }]), i
        }(),
        Pt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        button: "handleClick"
                    }
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.redirectUrl = this.el.dataset.formredirectUrl
                }
            }, {
                key: "handleClick",
                value: function(t) {
                    t.preventDefault(), this.el.submit(), window.location = this.redirectUrl
                }
            }]), i
        }(),
        Dt = ".js-howtouse-toshow",
        jt = ".js-howtouse-parent",
        Bt = ".cta-signup > button",
        Ht = '[data-scroll-target="signup"]',
        _t = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        triggerer: "show"
                    }
                }, t.el.querySelector(Dt).style.opacity = 0, t.el.querySelector(Dt).style.height = 0, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var e = this,
                        t = document.querySelector(Bt);
                    t && t.addEventListener("click", function(t) {
                        t.preventDefault();
                        t = document.querySelector(Ht);
                        return t && e.call("scrollTo", t, "scroll", "main"), !1
                    })
                }
            }, {
                key: "show",
                value: function(t) {
                    $(t.currentTarget).hide(), this.el.querySelector(Dt).style.opacity = 1, this.el.querySelector(Dt).style.height = "auto", document.querySelector(jt).dataset.expanded = !0, this.call("startAutoPlay", null, "carouselwithpagination")
                }
            }]), i
        }();

    function Rt(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
        }
    }

    function Ft(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            var i = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != i) {
                var n, s, o = [],
                    r = !0,
                    a = !1;
                try {
                    for (i = i.call(t); !(r = (n = i.next()).done) && (o.push(n.value), !e || o.length !== e); r = !0);
                } catch (t) {
                    a = !0, s = t
                } finally {
                    try {
                        r || null == i.return || i.return()
                    } finally {
                        if (a) throw s
                    }
                }
                return o
            }
        }(t, e) || function(t, e) {
            if (t) {
                if ("string" == typeof t) return Wt(t, e);
                var i = Object.prototype.toString.call(t).slice(8, -1);
                return "Map" === (i = "Object" === i && t.constructor ? t.constructor.name : i) || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? Wt(t, e) : void 0
            }
        }(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Wt(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
        return n
    }
    var qt = function() {
            function e(t) {
                ! function(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }(this, e), this.defaults = {
                    name: "load",
                    loadingClass: "is-loading",
                    loadedClass: "is-loaded",
                    readyClass: "is-ready",
                    transitionsPrefix: "is-",
                    transitionsHistory: !0,
                    enterDelay: 0,
                    exitDelay: 0,
                    loadedDelay: 0,
                    isLoaded: !1,
                    isEntered: !1,
                    isUrl: !1,
                    transitionContainer: null,
                    popstateIgnore: !1
                }, Object.assign(this, this.defaults, t), this.options = t, this.namespace = "modular", this.html = document.documentElement, this.href = window.location.href, this.container = "data-" + this.name + "-container", this.subContainer = !1, this.prevTransition = null, this.loadAttributes = ["src", "srcset", "style", "href"], this.isInserted = !1, this.isLoading = !1, this.enterTimeout = !1, this.controller = new AbortController, this.classContainer = this.html, this.isChrome = -1 != navigator.userAgent.indexOf("Chrome"), this.init()
            }
            var t, i, n;
            return t = e, (i = [{
                key: "init",
                value: function() {
                    var e = this;
                    window.addEventListener("popstate", function(t) {
                        return e.checkState(t)
                    }, !1), this.html.addEventListener("click", function(t) {
                        return e.checkClick(t)
                    }, !1), this.loadEls(document)
                }
            }, {
                key: "checkClick",
                value: function(t) {
                    if (!t.ctrlKey && !t.metaKey)
                        for (var e = t.target; e && e !== document;) {
                            if (e.matches("a") && null == e.getAttribute("download")) {
                                var i = e.getAttribute("href");
                                i.startsWith("#") || i.startsWith("mailto:") || i.startsWith("tel:") || (t.preventDefault(), this.reset(), this.getClickOptions(e));
                                break
                            }
                            e = e.parentNode
                        }
                }
            }, {
                key: "checkState",
                value: function() {
                    "string" == typeof this.popstateIgnore && -1 < window.location.href.indexOf(this.popstateIgnore) || (this.reset(), this.getStateOptions())
                }
            }, {
                key: "reset",
                value: function() {
                    this.isLoading && (this.controller.abort(), this.isLoading = !1, this.controller = new AbortController), window.clearTimeout(this.enterTimeout), this.isInserted && this.removeContainer(), this.classContainer = this.html, Object.assign(this, this.defaults, this.options)
                }
            }, {
                key: "getClickOptions",
                value: function(t) {
                    this.transition = t.getAttribute("data-" + this.name), this.isUrl = t.getAttribute("data-" + this.name + "-url");
                    var e = t.getAttribute("href");
                    "_blank" != t.getAttribute("target") ? "false" != this.transition ? this.setOptions(e, !0) : window.location = e : window.open(e, "_blank")
                }
            }, {
                key: "getStateOptions",
                value: function() {
                    this.transitionsHistory ? this.transition = history.state : this.transition = !1;
                    var t = window.location.href;
                    this.setOptions(t)
                }
            }, {
                key: "goTo",
                value: function(t, e, i) {
                    this.reset(), this.transition = e, this.isUrl = i, this.setOptions(t, !0)
                }
            }, {
                key: "setOptions",
                value: function(t, e) {
                    var i, n = "[" + this.container + "]";
                    this.transition && "true" != this.transition && (this.transitionContainer = "[" + this.container + '="' + this.transition + '"]', this.loadingClass = this.transitions[this.transition].loadingClass || this.loadingClass, this.loadedClass = this.transitions[this.transition].loadedClass || this.loadedClass, this.readyClass = this.transitions[this.transition].readyClass || this.readyClass, this.transitionsPrefix = this.transitions[this.transition].transitionsPrefix || this.transitionsPrefix, this.enterDelay = this.transitions[this.transition].enterDelay || this.enterDelay, this.exitDelay = this.transitions[this.transition].exitDelay || this.exitDelay, this.loadedDelay = this.transitions[this.transition].loadedDelay || this.loadedDelay, i = document.querySelector(this.transitionContainer)), i ? (n = this.transitionContainer, this.oldContainer = i, this.classContainer = this.oldContainer.parentNode, this.subContainer || history.replaceState(this.transition, null, this.href), this.subContainer = !0) : (this.oldContainer = document.querySelector(n), this.subContainer && history.replaceState(this.prevTransition, null, this.href), this.subContainer = !1), this.href = t, this.parentContainer = this.oldContainer.parentNode, "" === this.isUrl || null != this.isUrl && "false" != this.isUrl && 0 != this.isUrl ? history.pushState(this.transition, null, t) : (this.oldContainer.classList.add("is-old"), this.setLoading(), this.startEnterDelay(), this.loadHref(t, n, e))
                }
            }, {
                key: "setLoading",
                value: function() {
                    this.classContainer.classList.remove(this.loadedClass, this.readyClass), this.classContainer.classList.add(this.loadingClass), this.classContainer.classList.remove(this.transitionsPrefix + this.prevTransition), this.transition && this.classContainer.classList.add(this.transitionsPrefix + this.transition), this.subContainer || (this.prevTransition = this.transition);
                    var t = new Event(this.namespace + "loading");
                    window.dispatchEvent(t)
                }
            }, {
                key: "startEnterDelay",
                value: function() {
                    var t = this;
                    this.enterTimeout = window.setTimeout(function() {
                        t.isEntered = !0, t.isLoaded && t.transitionContainers()
                    }, this.enterDelay)
                }
            }, {
                key: "loadHref",
                value: function(i, n, s) {
                    var o = this;
                    this.isLoading = !0;
                    var t = this.controller.signal;
                    fetch(i, {
                        signal: t
                    }).then(function(t) {
                        return t.text()
                    }).then(function(t) {
                        s && history.pushState(o.transition, null, i);
                        var e = new DOMParser;
                        o.data = e.parseFromString(t, "text/html"), o.newContainer = o.data.querySelector(n), o.newContainer.classList.add("is-new"), o.parentNewContainer = o.newContainer.parentNode, o.hideContainer(), o.parentContainer.insertBefore(o.newContainer, o.oldContainer), o.isInserted = !0, o.setSvgs(), o.isLoaded = !0, o.isEntered && o.transitionContainers(), o.loadEls(o.newContainer), o.isLoading = !1
                    }).catch(function(t) {
                        window.location = i
                    })
                }
            }, {
                key: "transitionContainers",
                value: function() {
                    var t = this;
                    this.setAttributes(), this.showContainer(), this.setLoaded(), setTimeout(function() {
                        t.removeContainer(), t.setReady()
                    }, this.exitDelay)
                }
            }, {
                key: "setSvgs",
                value: function() {
                    var t;
                    !this.isChrome || (t = this.newContainer.querySelectorAll("use")).length && t.forEach(function(t) {
                        var e = t.getAttribute("xlink:href");
                        e ? t.parentNode.innerHTML = '<use xlink:href="' + e + '"></use>' : (e = t.getAttribute("href")) && (t.parentNode.innerHTML = '<use href="' + e + '"></use>')
                    })
                }
            }, {
                key: "setAttributes",
                value: function() {
                    var i = this,
                        t = this.data.getElementsByTagName("title")[0],
                        e = this.data.head.querySelector('meta[name="description"]'),
                        n = document.head.querySelector('meta[name="description"]'),
                        s = this.subContainer ? (o = this.parentNewContainer, document.querySelector(this.transitionContainer).parentNode) : (o = this.data.querySelector("html"), document.querySelector("html")),
                        o = Object.assign({}, o.dataset);
                    t && (document.title = t.innerText), n && e && n.setAttribute("content", e.getAttribute("content")), o && Object.entries(o).forEach(function(t) {
                        var e = Ft(t, 2),
                            t = e[0],
                            e = e[1];
                        s.setAttribute("data-" + i.toDash(t), e)
                    })
                }
            }, {
                key: "toDash",
                value: function(t) {
                    return t.split(/(?=[A-Z])/).join("-").toLowerCase()
                }
            }, {
                key: "hideContainer",
                value: function() {
                    this.newContainer.style.visibility = "hidden", this.newContainer.style.height = 0, this.newContainer.style.overflow = "hidden"
                }
            }, {
                key: "showContainer",
                value: function() {
                    this.newContainer.style.visibility = "", this.newContainer.style.height = "", this.newContainer.style.overflow = ""
                }
            }, {
                key: "loadEls",
                value: function(e) {
                    var s = this,
                        o = [];
                    this.loadAttributes.forEach(function(i) {
                        var n = "data-" + s.name + "-" + i,
                            t = e.querySelectorAll("[" + n + "]");
                        t.length && t.forEach(function(e) {
                            var t = e.getAttribute(n);
                            e.setAttribute(i, t), "src" != i && "srcset" != i || (t = new Promise(function(t) {
                                e.onload = function() {
                                    return t(e)
                                }
                            }), o.push(t))
                        })
                    }), Promise.all(o).then(function(t) {
                        var e = new Event(s.namespace + "images");
                        window.dispatchEvent(e)
                    })
                }
            }, {
                key: "setLoaded",
                value: function() {
                    var t = this;
                    this.classContainer.classList.remove(this.loadingClass), setTimeout(function() {
                        t.classContainer.classList.add(t.loadedClass)
                    }, this.loadedDelay);
                    var e = new Event(this.namespace + "loaded");
                    window.dispatchEvent(e)
                }
            }, {
                key: "removeContainer",
                value: function() {
                    this.parentContainer.removeChild(this.oldContainer), this.newContainer.classList.remove("is-new"), this.isInserted = !1
                }
            }, {
                key: "setReady",
                value: function() {
                    this.classContainer.classList.add(this.readyClass);
                    var t = new Event(this.namespace + "ready");
                    window.dispatchEvent(t)
                }
            }, {
                key: "on",
                value: function(t, e) {
                    var i = this;
                    window.addEventListener(this.namespace + t, function() {
                        switch (t) {
                            case "loading":
                                return e(i.transition, i.oldContainer);
                            case "loaded":
                                return e(i.transition, i.oldContainer, i.newContainer);
                            case "ready":
                                return e(i.transition, i.newContainer);
                            default:
                                return e()
                        }
                    }, !1)
                }
            }]) && Rt(t.prototype, i), n && Rt(t, n), e
        }(),
        $t = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var n = this;
                    this.load = new qt({
                        enterDelay: 600,
                        transitions: {
                            menu: {
                                enterDelay: 1200
                            }
                        }
                    }), this.load.on("loading", function(t, e) {
                        n.call("close", !1, "menutoggler"), document.documentElement.classList.add("is-leaving")
                    }), this.load.on("loaded", function(t, e, i) {
                        n.call("destroy", e, "app"), window.gtag && gtag("config", "UA-125263849-1", {
                            page_path: location.pathname,
                            page_title: document.title
                        }), document.documentElement.scrollTop = 0, document.body.scrollTop = 0, document.documentElement.classList.remove("is-leaving")
                    }), this.load.on("ready", function(t, e) {
                        n.call("update", e, "app")
                    }), this.load.on("images", function() {
                        n.call("update", null, "scroll", "main")
                    }), window.onload = function(t) {
                        document.documentElement.classList.add("is-loaded")
                    }
                }
            }, {
                key: "goTo",
                value: function(t) {
                    this.load.goTo(t)
                }
            }]), i
        }(),
        zt = "".concat(E, ".").concat("LottieHeader"),
        Yt = "/assets/lottie-theme-".concat(window.colorsetIndex, "/"),
        Ut = !0,
        Nt = !0,
        Vt = "svg",
        Xt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).$el = $(t.el), t.$container = t.$el, t.container = t.$container[0], t.fileName = t.getData("file"), t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var n = this;
                    window.isSafari && lottie.setLocationHref(document.location.href), this.lottiePromise = this.loadAnimationByName(this.fileName).then(function(t) {
                        if (!n.toDestroy) {
                            var i = lottie.loadAnimation({
                                container: n.container,
                                animType: Vt,
                                loop: Ut,
                                autoplay: Nt,
                                animationData: t,
                                rendererSettings: {
                                    preserveAspectRatio: "xMidYMid slice"
                                }
                            });
                            return n.animation = {
                                lottieAnim: i,
                                data: t
                            }, new Promise(function(t, e) {
                                i.addEventListener("DOMLoaded", function() {
                                    t(), window.lottiePromises.splice(window.lottiePromises.indexOf(n.lottiePromise), 1)
                                })
                            })
                        }
                    }).catch(function(t) {
                        console.error(t)
                    }), window.lottiePromises.push(this.lottiePromise)
                }
            }, {
                key: "loadAnimationByName",
                value: function(t) {
                    return new Promise(function(e, i) {
                        fetch(Yt + t + ".json").then(function(t) {
                            return t.json()
                        }).then(function(t) {
                            t.assets.map(function(t) {
                                return t.u && t.u.length && (t.u = Yt + t.u), t
                            }), e(t)
                        }).catch(function(t) {
                            i(t)
                        })
                    })
                }
            }, {
                key: "toggle",
                value: function(t) {
                    this.animation && this.animation.lottieAnim && this.animation.lottieAnim.play && this.animation.lottieAnim.pause && ("enter" === t.way ? this.animation.lottieAnim.play() : this.animation.lottieAnim.pause())
                }
            }, {
                key: "destroy",
                value: function() {
                    w(m(i.prototype), "destroy", this).call(this), this.$el.off(".".concat(zt)), this.toDestroy = !0
                }
            }]), i
        }(),
        Kt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).isOpen = !1, t.events = {
                    click: "toggler"
                }, t
            }
            return f(i, [{
                key: "init",
                value: function() {}
            }, {
                key: "toggler",
                value: function() {
                    this.isOpen ? this.close() : this.open()
                }
            }, {
                key: "open",
                value: function() {
                    this.isOpen = !0, document.documentElement.classList.add("has-menu-open")
                }
            }, {
                key: "close",
                value: function() {
                    this.isOpen = !1, document.documentElement.classList.remove("has-menu-open")
                }
            }]), i
        }(),
        Zt = "lightbox-temp-is-open",
        Gt = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), (t = e.call(this, t)).events = {
                    click: {
                        triggerer: "trigger",
                        close: "close"
                    }
                }, t.cookieType = {
                    popup: "swab-the-world-popup"
                }, t.handlers = {
                    close: t.close.bind(v(t))
                }, t.player = null, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.initPopup()
                }
            }, {
                key: "initPopup",
                value: function() {
                    var e = this;
                    document.documentElement.classList.add(Zt), this.el.classList.remove("-is-hidden");
                    var t = document.createElement("script");
                    t.src = "https://www.youtube.com/iframe_api", console.log(this.$("player"));
                    var i = "fr" === document.getElementsByTagName("html")[0].getAttribute("lang") ? this.$("player")[0].dataset.idFr : this.$("player")[0].dataset.idEn,
                        n = document.getElementsByTagName("script")[0];
                    n.parentNode.insertBefore(t, n), window.onYouTubePlayerAPIReady = function() {
                        e.player = new YT.Player("player", {
                            height: "360",
                            width: "640",
                            videoId: i,
                            playerVars: {
                                autoplay: 1,
                                mute: 1
                            },
                            events: {
                                onReady: function() {}
                            }
                        })
                    }, document.onkeydown = function(t) {
                        "Escape" === (t = t || window.event).key && e.handlers.close()
                    }
                }
            }, {
                key: "onPlayerReady",
                value: function(t) {
                    t.target.playVideo()
                }
            }, {
                key: "close",
                value: function() {
                    this.el.classList.add("-is-hidden"), this.player.mute()
                }
            }, {
                key: "destroy",
                value: function() {
                    document.onkeydown = function(t) {
                        "Escape" === (t = t || window.event).key && this.handlers.close()
                    }
                }
            }]), i
        }();

    function Jt(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function Qt(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
        }
    }

    function te(t, e, i) {
        return e && Qt(t.prototype, e), i && Qt(t, i), t
    }

    function ee(e, t) {
        var i, n = Object.keys(e);
        return Object.getOwnPropertySymbols && (i = Object.getOwnPropertySymbols(e), t && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), n.push.apply(n, i)), n
    }

    function ie(n) {
        for (var t = 1; t < arguments.length; t++) {
            var s = null != arguments[t] ? arguments[t] : {};
            t % 2 ? ee(Object(s), !0).forEach(function(t) {
                var e, i;
                e = n, t = s[i = t], i in e ? Object.defineProperty(e, i, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[i] = t
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(s)) : ee(Object(s)).forEach(function(t) {
                Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(s, t))
            })
        }
        return n
    }

    function ne(t, e) {
        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
        t.prototype = Object.create(e && e.prototype, {
            constructor: {
                value: t,
                writable: !0,
                configurable: !0
            }
        }), e && oe(t, e)
    }

    function se(t) {
        return (se = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
            return t.__proto__ || Object.getPrototypeOf(t)
        })(t)
    }

    function oe(t, e) {
        return (oe = Object.setPrototypeOf || function(t, e) {
            return t.__proto__ = e, t
        })(t, e)
    }

    function re(t) {
        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return t
    }

    function ae(i) {
        var n = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
            } catch (t) {
                return !1
            }
        }();
        return function() {
            var t, e = se(i);
            return t = n ? (t = se(this).constructor, Reflect.construct(e, arguments, t)) : e.apply(this, arguments), e = this, !(t = t) || "object" != typeof t && "function" != typeof t ? re(e) : t
        }
    }

    function le(t, e, i) {
        return (le = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, i) {
            t = function(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = se(t)););
                return t
            }(t, e);
            if (t) {
                e = Object.getOwnPropertyDescriptor(t, e);
                return e.get ? e.get.call(i) : e.value
            }
        })(t, e, i || t)
    }

    function ce(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                var i = [],
                    n = !0,
                    s = !1,
                    o = void 0;
                try {
                    for (var r, a = t[Symbol.iterator](); !(n = (r = a.next()).done) && (i.push(r.value), !e || i.length !== e); n = !0);
                } catch (t) {
                    s = !0, o = t
                } finally {
                    try {
                        n || null == a.return || a.return()
                    } finally {
                        if (s) throw o
                    }
                }
                return i
            }
        }(t, e) || ue(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function he(t) {
        return function(t) {
            if (Array.isArray(t)) return de(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || ue(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function ue(t, e) {
        if (t) {
            if ("string" == typeof t) return de(t, e);
            var i = Object.prototype.toString.call(t).slice(8, -1);
            return "Map" === (i = "Object" === i && t.constructor ? t.constructor.name : i) || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? de(t, e) : void 0
        }
    }

    function de(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var i = 0, n = new Array(e); i < e; i++) n[i] = t[i];
        return n
    }
    var fe = {
            el: document,
            name: "scroll",
            offset: [0, 0],
            repeat: !1,
            smooth: !1,
            initPosition: {
                x: 0,
                y: 0
            },
            direction: "vertical",
            gestureDirection: "vertical",
            reloadOnContextChange: !1,
            lerp: .1,
            class: "is-inview",
            scrollbarContainer: !1,
            scrollbarClass: "c-scrollbar",
            scrollingClass: "has-scroll-scrolling",
            draggingClass: "has-scroll-dragging",
            smoothClass: "has-scroll-smooth",
            initClass: "has-scroll-init",
            getSpeed: !1,
            getDirection: !1,
            scrollFromAnywhere: !1,
            multiplier: 1,
            firefoxMultiplier: 50,
            touchMultiplier: 2,
            resetNativeScroll: !0,
            tablet: {
                smooth: !1,
                direction: "vertical",
                gestureDirection: "vertical",
                breakpoint: 1024
            },
            smartphone: {
                smooth: !1,
                direction: "vertical",
                gestureDirection: "vertical"
            }
        },
        pe = function() {
            function e() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                Jt(this, e), Object.assign(this, fe, t), this.smartphone = fe.smartphone, t.smartphone && Object.assign(this.smartphone, t.smartphone), this.tablet = fe.tablet, t.tablet && Object.assign(this.tablet, t.tablet), this.namespace = "locomotive", this.html = document.documentElement, this.windowHeight = window.innerHeight, this.windowWidth = window.innerWidth, this.windowMiddle = {
                    x: this.windowWidth / 2,
                    y: this.windowHeight / 2
                }, this.els = {}, this.currentElements = {}, this.listeners = {}, this.hasScrollTicking = !1, this.hasCallEventSet = !1, this.checkScroll = this.checkScroll.bind(this), this.checkResize = this.checkResize.bind(this), this.checkEvent = this.checkEvent.bind(this), this.instance = {
                    scroll: {
                        x: 0,
                        y: 0
                    },
                    limit: {
                        x: this.html.offsetWidth,
                        y: this.html.offsetHeight
                    },
                    currentElements: this.currentElements
                }, this.isMobile ? this.isTablet ? this.context = "tablet" : this.context = "smartphone" : this.context = "desktop", this.isMobile && (this.direction = this[this.context].direction), "horizontal" === this.direction ? this.directionAxis = "x" : this.directionAxis = "y", this.getDirection && (this.instance.direction = null), this.getDirection && (this.instance.speed = 0), this.html.classList.add(this.initClass), window.addEventListener("resize", this.checkResize, !1)
            }
            return te(e, [{
                key: "init",
                value: function() {
                    this.initEvents()
                }
            }, {
                key: "checkScroll",
                value: function() {
                    this.dispatchScroll()
                }
            }, {
                key: "checkResize",
                value: function() {
                    var t = this;
                    this.resizeTick || (this.resizeTick = !0, requestAnimationFrame(function() {
                        t.resize(), t.resizeTick = !1
                    }))
                }
            }, {
                key: "resize",
                value: function() {}
            }, {
                key: "checkContext",
                value: function() {
                    var t;
                    this.reloadOnContextChange && (this.isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || "MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints || this.windowWidth < this.tablet.breakpoint, this.isTablet = this.isMobile && this.windowWidth >= this.tablet.breakpoint, t = this.context, this.isMobile ? this.isTablet ? this.context = "tablet" : this.context = "smartphone" : this.context = "desktop", t != this.context && ("desktop" == t ? this : this[t]).smooth != ("desktop" == this.context ? this : this[this.context]).smooth && window.location.reload())
                }
            }, {
                key: "initEvents",
                value: function() {
                    var e = this;
                    this.scrollToEls = this.el.querySelectorAll("[data-".concat(this.name, "-to]")), this.setScrollTo = this.setScrollTo.bind(this), this.scrollToEls.forEach(function(t) {
                        t.addEventListener("click", e.setScrollTo, !1)
                    })
                }
            }, {
                key: "setScrollTo",
                value: function(t) {
                    t.preventDefault(), this.scrollTo(t.currentTarget.getAttribute("data-".concat(this.name, "-href")) || t.currentTarget.getAttribute("href"), {
                        offset: t.currentTarget.getAttribute("data-".concat(this.name, "-offset"))
                    })
                }
            }, {
                key: "addElements",
                value: function() {}
            }, {
                key: "detectElements",
                value: function(n) {
                    var s = this,
                        o = this.instance.scroll.y,
                        r = o + this.windowHeight,
                        a = this.instance.scroll.x,
                        l = a + this.windowWidth;
                    Object.entries(this.els).forEach(function(t) {
                        var e, i = ce(t, 2),
                            t = i[0],
                            i = i[1];
                        !i || i.inView && !n || ("horizontal" === s.direction ? l >= i.left && a < i.right && s.setInView(i, t) : r >= i.top && o < i.bottom && s.setInView(i, t)), i && i.inView && ("horizontal" === s.direction ? (e = i.right - i.left, i.progress = (s.instance.scroll.x - (i.left - s.windowWidth)) / (e + s.windowWidth), (l < i.left || a > i.right) && s.setOutOfView(i, t)) : (e = i.bottom - i.top, i.progress = (s.instance.scroll.y - (i.top - s.windowHeight)) / (e + s.windowHeight), (r < i.top || o > i.bottom) && s.setOutOfView(i, t)))
                    }), this.hasScrollTicking = !1
                }
            }, {
                key: "setInView",
                value: function(t, e) {
                    this.els[e].inView = !0, t.el.classList.add(t.class), (this.currentElements[e] = t).call && this.hasCallEventSet && (this.dispatchCall(t, "enter"), t.repeat || (this.els[e].call = !1))
                }
            }, {
                key: "setOutOfView",
                value: function(t, e) {
                    var i = this;
                    this.els[e].inView = !1, Object.keys(this.currentElements).forEach(function(t) {
                        t === e && delete i.currentElements[t]
                    }), t.call && this.hasCallEventSet && this.dispatchCall(t, "exit"), t.repeat && t.el.classList.remove(t.class)
                }
            }, {
                key: "dispatchCall",
                value: function(t, e) {
                    this.callWay = e, this.callValue = t.call.split(",").map(function(t) {
                        return t.trim()
                    }), this.callObj = t, 1 == this.callValue.length && (this.callValue = this.callValue[0]);
                    t = new Event(this.namespace + "call");
                    this.el.dispatchEvent(t)
                }
            }, {
                key: "dispatchScroll",
                value: function() {
                    var t = new Event(this.namespace + "scroll");
                    this.el.dispatchEvent(t)
                }
            }, {
                key: "setEvents",
                value: function(t, e) {
                    this.listeners[t] || (this.listeners[t] = []);
                    var i = this.listeners[t];
                    i.push(e), 1 === i.length && this.el.addEventListener(this.namespace + t, this.checkEvent, !1), "call" === t && (this.hasCallEventSet = !0, this.detectElements(!0))
                }
            }, {
                key: "unsetEvents",
                value: function(t, e) {
                    var i;
                    this.listeners[t] && ((e = (i = this.listeners[t]).indexOf(e)) < 0 || (i.splice(e, 1), 0 === i.index && this.el.removeEventListener(this.namespace + t, this.checkEvent, !1)))
                }
            }, {
                key: "checkEvent",
                value: function(t) {
                    var e = this,
                        i = t.type.replace(this.namespace, ""),
                        t = this.listeners[i];
                    t && 0 !== t.length && t.forEach(function(t) {
                        switch (i) {
                            case "scroll":
                                return t(e.instance);
                            case "call":
                                return t(e.callValue, e.callWay, e.callObj);
                            default:
                                return t()
                        }
                    })
                }
            }, {
                key: "startScroll",
                value: function() {}
            }, {
                key: "stopScroll",
                value: function() {}
            }, {
                key: "setScroll",
                value: function(t, e) {
                    this.instance.scroll = {
                        x: 0,
                        y: 0
                    }
                }
            }, {
                key: "destroy",
                value: function() {
                    var e = this;
                    window.removeEventListener("resize", this.checkResize, !1), Object.keys(this.listeners).forEach(function(t) {
                        e.el.removeEventListener(e.namespace + t, e.checkEvent, !1)
                    }), this.listeners = {}, this.scrollToEls.forEach(function(t) {
                        t.removeEventListener("click", e.setScrollTo, !1)
                    }), this.html.classList.remove(this.initClass)
                }
            }]), e
        }(),
        me = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function ye(t, e) {
        return t(e = {
            exports: {}
        }, e.exports), e.exports
    }
    var ve = ye(function(t, e) {
        function i() {
            var t, n, a, l, i, e, c = window,
                h = document;

            function u(t, e) {
                this.scrollLeft = t, this.scrollTop = e
            }

            function s(t) {
                if (null === t || "object" != typeof t || void 0 === t.behavior || "auto" === t.behavior || "instant" === t.behavior) return !0;
                if ("object" == typeof t && "smooth" === t.behavior) return !1;
                throw new TypeError("behavior member of ScrollOptions " + t.behavior + " is not a valid value for enumeration ScrollBehavior.")
            }

            function o(t, e) {
                return "Y" === e ? t.clientHeight + i < t.scrollHeight : "X" === e ? t.clientWidth + i < t.scrollWidth : void 0
            }

            function r(t, e) {
                e = c.getComputedStyle(t, null)["overflow" + e];
                return "auto" === e || "scroll" === e
            }

            function d(t) {
                for (; t !== h.body && !1 === (i = void 0, i = o(e = t, "Y") && r(e, "Y"), e = o(e, "X") && r(e, "X"), i || e);) t = t.parentNode || t.host;
                var e, i;
                return t
            }

            function f(t) {
                var e, i = (l() - t.startTime) / n;
                e = i = 1 < i ? 1 : i, i = .5 * (1 - Math.cos(Math.PI * e)), e = t.startX + (t.x - t.startX) * i, i = t.startY + (t.y - t.startY) * i, t.method.call(t.scrollable, e, i), e === t.x && i === t.y || c.requestAnimationFrame(f.bind(c, t))
            }

            function p(t, e, i) {
                var n, s, o, r = l(),
                    t = t === h.body ? (s = (n = c).scrollX || c.pageXOffset, o = c.scrollY || c.pageYOffset, a.scroll) : (s = (n = t).scrollLeft, o = t.scrollTop, u);
                f({
                    scrollable: n,
                    method: t,
                    startTime: r,
                    startX: s,
                    startY: o,
                    x: e,
                    y: i
                })
            }
            "scrollBehavior" in h.documentElement.style && !0 !== c.__forceSmoothScrollPolyfill__ || (t = c.HTMLElement || c.Element, n = 468, a = {
                scroll: c.scroll || c.scrollTo,
                scrollBy: c.scrollBy,
                elementScroll: t.prototype.scroll || u,
                scrollIntoView: t.prototype.scrollIntoView
            }, l = c.performance && c.performance.now ? c.performance.now.bind(c.performance) : Date.now, e = c.navigator.userAgent, i = new RegExp(["MSIE ", "Trident/", "Edge/"].join("|")).test(e) ? 1 : 0, c.scroll = c.scrollTo = function() {
                void 0 !== arguments[0] && (!0 !== s(arguments[0]) ? p.call(c, h.body, void 0 !== arguments[0].left ? ~~arguments[0].left : c.scrollX || c.pageXOffset, void 0 !== arguments[0].top ? ~~arguments[0].top : c.scrollY || c.pageYOffset) : a.scroll.call(c, void 0 !== arguments[0].left ? arguments[0].left : "object" != typeof arguments[0] ? arguments[0] : c.scrollX || c.pageXOffset, void 0 !== arguments[0].top ? arguments[0].top : void 0 !== arguments[1] ? arguments[1] : c.scrollY || c.pageYOffset))
            }, c.scrollBy = function() {
                void 0 !== arguments[0] && (s(arguments[0]) ? a.scrollBy.call(c, void 0 !== arguments[0].left ? arguments[0].left : "object" != typeof arguments[0] ? arguments[0] : 0, void 0 !== arguments[0].top ? arguments[0].top : void 0 !== arguments[1] ? arguments[1] : 0) : p.call(c, h.body, ~~arguments[0].left + (c.scrollX || c.pageXOffset), ~~arguments[0].top + (c.scrollY || c.pageYOffset)))
            }, t.prototype.scroll = t.prototype.scrollTo = function() {
                if (void 0 !== arguments[0])
                    if (!0 !== s(arguments[0])) {
                        var t = arguments[0].left,
                            e = arguments[0].top;
                        p.call(this, this, void 0 === t ? this.scrollLeft : ~~t, void 0 === e ? this.scrollTop : ~~e)
                    } else {
                        if ("number" == typeof arguments[0] && void 0 === arguments[1]) throw new SyntaxError("Value could not be converted");
                        a.elementScroll.call(this, void 0 !== arguments[0].left ? ~~arguments[0].left : "object" != typeof arguments[0] ? ~~arguments[0] : this.scrollLeft, void 0 !== arguments[0].top ? ~~arguments[0].top : void 0 !== arguments[1] ? ~~arguments[1] : this.scrollTop)
                    }
            }, t.prototype.scrollBy = function() {
                void 0 !== arguments[0] && (!0 !== s(arguments[0]) ? this.scroll({
                    left: ~~arguments[0].left + this.scrollLeft,
                    top: ~~arguments[0].top + this.scrollTop,
                    behavior: arguments[0].behavior
                }) : a.elementScroll.call(this, void 0 !== arguments[0].left ? ~~arguments[0].left + this.scrollLeft : ~~arguments[0] + this.scrollLeft, void 0 !== arguments[0].top ? ~~arguments[0].top + this.scrollTop : ~~arguments[1] + this.scrollTop))
            }, t.prototype.scrollIntoView = function() {
                var t, e, i;
                !0 !== s(arguments[0]) ? (e = (t = d(this)).getBoundingClientRect(), i = this.getBoundingClientRect(), t !== h.body ? (p.call(this, t, t.scrollLeft + i.left - e.left, t.scrollTop + i.top - e.top), "fixed" !== c.getComputedStyle(t).position && c.scrollBy({
                    left: e.left,
                    top: e.top,
                    behavior: "smooth"
                })) : c.scrollBy({
                    left: i.left,
                    top: i.top,
                    behavior: "smooth"
                })) : a.scrollIntoView.call(this, void 0 === arguments[0] || arguments[0])
            })
        }
        t.exports = {
            polyfill: i
        }
    });
    ve.polyfill;
    var ge = function() {
            ne(i, pe);
            var e = ae(i);

            function i() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                return Jt(this, i), (t = e.call(this, t)).resetNativeScroll && (history.scrollRestoration && (history.scrollRestoration = "manual"), window.scrollTo(0, 0)), window.addEventListener("scroll", t.checkScroll, !1), void 0 === window.smoothscrollPolyfill && (window.smoothscrollPolyfill = ve, window.smoothscrollPolyfill.polyfill()), t
            }
            return te(i, [{
                key: "init",
                value: function() {
                    this.instance.scroll.y = window.pageYOffset, this.addElements(), this.detectElements(), le(se(i.prototype), "init", this).call(this)
                }
            }, {
                key: "checkScroll",
                value: function() {
                    var t = this;
                    le(se(i.prototype), "checkScroll", this).call(this), this.getDirection && this.addDirection(), this.getSpeed && (this.addSpeed(), this.speedTs = Date.now()), this.instance.scroll.y = window.pageYOffset, Object.entries(this.els).length && (this.hasScrollTicking || (requestAnimationFrame(function() {
                        t.detectElements()
                    }), this.hasScrollTicking = !0))
                }
            }, {
                key: "addDirection",
                value: function() {
                    window.pageYOffset > this.instance.scroll.y ? "down" !== this.instance.direction && (this.instance.direction = "down") : window.pageYOffset < this.instance.scroll.y && "up" !== this.instance.direction && (this.instance.direction = "up")
                }
            }, {
                key: "addSpeed",
                value: function() {
                    window.pageYOffset != this.instance.scroll.y ? this.instance.speed = (window.pageYOffset - this.instance.scroll.y) / Math.max(1, Date.now() - this.speedTs) : this.instance.speed = 0
                }
            }, {
                key: "resize",
                value: function() {
                    Object.entries(this.els).length && (this.windowHeight = window.innerHeight, this.updateElements())
                }
            }, {
                key: "addElements",
                value: function() {
                    var d = this;
                    this.els = {}, this.el.querySelectorAll("[data-" + this.name + "]").forEach(function(t, e) {
                        t.getBoundingClientRect();
                        var i = t.dataset[d.name + "Class"] || d.class,
                            n = "string" == typeof t.dataset[d.name + "Id"] ? t.dataset[d.name + "Id"] : e,
                            s = "string" == typeof t.dataset[d.name + "Offset"] ? t.dataset[d.name + "Offset"].split(",") : d.offset,
                            o = t.dataset[d.name + "Repeat"],
                            r = t.dataset[d.name + "Call"],
                            a = t.dataset[d.name + "Target"],
                            l = void 0 !== a ? document.querySelector("".concat(a)) : t,
                            c = l.getBoundingClientRect(),
                            h = c.top + d.instance.scroll.y,
                            u = c.left + d.instance.scroll.x,
                            e = h + l.offsetHeight,
                            a = u + l.offsetWidth,
                            o = "false" != o && (null != o || d.repeat),
                            c = d.getRelativeOffset(s);
                        h += c[0], e -= c[1], d.els[n] = {
                            el: t,
                            targetEl: l,
                            id: n,
                            class: i,
                            top: h,
                            bottom: e,
                            left: u,
                            right: a,
                            offset: s,
                            progress: 0,
                            repeat: o,
                            inView: !1,
                            call: r
                        }, t.classList.contains(i) && d.setInView(d.els[n], n)
                    })
                }
            }, {
                key: "updateElements",
                value: function() {
                    var s = this;
                    Object.entries(this.els).forEach(function(t) {
                        var e = ce(t, 2),
                            i = e[0],
                            n = e[1],
                            t = n.targetEl.getBoundingClientRect().top + s.instance.scroll.y,
                            e = t + n.targetEl.offsetHeight,
                            n = s.getRelativeOffset(n.offset);
                        s.els[i].top = t + n[0], s.els[i].bottom = e - n[1]
                    }), this.hasScrollTicking = !1
                }
            }, {
                key: "getRelativeOffset",
                value: function(t) {
                    var e = [0, 0];
                    if (t)
                        for (var i = 0; i < t.length; i++) "string" == typeof t[i] ? t[i].includes("%") ? e[i] = parseInt(t[i].replace("%", "") * this.windowHeight / 100) : e[i] = parseInt(t[i]) : e[i] = t[i];
                    return e
                }
            }, {
                key: "scrollTo",
                value: function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        i = parseInt(e.offset) || 0,
                        n = e.callback || !1;
                    if ("string" == typeof t) {
                        if ("top" === t) t = this.html;
                        else if ("bottom" === t) t = this.html.offsetHeight - window.innerHeight;
                        else if (!(t = document.querySelector(t))) return
                    } else if ("number" == typeof t) t = parseInt(t);
                    else if (!t || !t.tagName) return void console.warn("`target` parameter is not valid");
                    var i = "number" != typeof t ? t.getBoundingClientRect().top + i + this.instance.scroll.y : t + i,
                        s = function() {
                            return parseInt(window.pageYOffset) === parseInt(i)
                        };
                    if (n) {
                        if (s()) return void n();
                        t = function t() {
                            s() && (window.removeEventListener("scroll", t), n())
                        };
                        window.addEventListener("scroll", t)
                    }
                    window.scrollTo({
                        top: i,
                        behavior: 0 === e.duration ? "auto" : "smooth"
                    })
                }
            }, {
                key: "update",
                value: function() {
                    this.addElements(), this.detectElements()
                }
            }, {
                key: "destroy",
                value: function() {
                    le(se(i.prototype), "destroy", this).call(this), window.removeEventListener("scroll", this.checkScroll, !1)
                }
            }]), i
        }(),
        we = Object.getOwnPropertySymbols,
        be = Object.prototype.hasOwnProperty,
        ke = Object.prototype.propertyIsEnumerable;
    var Ee = function() {
        try {
            if (!Object.assign) return;
            var t = new String("abc");
            if (t[5] = "de", "5" === Object.getOwnPropertyNames(t)[0]) return;
            for (var e = {}, i = 0; i < 10; i++) e["_" + String.fromCharCode(i)] = i;
            if ("0123456789" !== Object.getOwnPropertyNames(e).map(function(t) {
                    return e[t]
                }).join("")) return;
            var n = {};
            return "abcdefghijklmnopqrst".split("").forEach(function(t) {
                n[t] = t
            }), "abcdefghijklmnopqrst" !== Object.keys(Object.assign({}, n)).join("") ? void 0 : 1
        } catch (t) {
            return
        }
    }() ? Object.assign : function(t, e) {
        for (var i, n = function(t) {
                if (null == t) throw new TypeError("Object.assign cannot be called with null or undefined");
                return Object(t)
            }(t), s = 1; s < arguments.length; s++) {
            for (var o in i = Object(arguments[s])) be.call(i, o) && (n[o] = i[o]);
            if (we)
                for (var r = we(i), a = 0; a < r.length; a++) ke.call(i, r[a]) && (n[r[a]] = i[r[a]])
        }
        return n
    };

    function Te() {}
    Te.prototype = {
        on: function(t, e, i) {
            var n = this.e || (this.e = {});
            return (n[t] || (n[t] = [])).push({
                fn: e,
                ctx: i
            }), this
        },
        once: function(t, e, i) {
            var n = this;

            function s() {
                n.off(t, s), e.apply(i, arguments)
            }
            return s._ = e, this.on(t, s, i)
        },
        emit: function(t) {
            for (var e = [].slice.call(arguments, 1), i = ((this.e || (this.e = {}))[t] || []).slice(), n = 0, s = i.length; n < s; n++) i[n].fn.apply(i[n].ctx, e);
            return this
        },
        off: function(t, e) {
            var i = this.e || (this.e = {}),
                n = i[t],
                s = [];
            if (n && e)
                for (var o = 0, r = n.length; o < r; o++) n[o].fn !== e && n[o].fn._ !== e && s.push(n[o]);
            return s.length ? i[t] = s : delete i[t], this
        }
    };

    function Se(t) {
        if (!t) return console.warn("bindAll requires at least one argument.");
        var e = Array.prototype.slice.call(arguments, 1);
        if (0 === e.length)
            for (var i in t) Le.call(t, i) && "function" == typeof t[i] && "[object Function]" == Oe.call(t[i]) && e.push(i);
        for (var n = 0; n < e.length; n++) {
            var s = e[n];
            t[s] = function(t, e) {
                return function() {
                    return t.apply(e, arguments)
                }
            }(t[s], t)
        }
    }
    var xe = Te,
        Ce = ye(function(t, e) {
            ! function() {
                function t(t, e, i, n) {
                    this.stability = null != t ? Math.abs(t) : 8, this.sensitivity = null != e ? 1 + Math.abs(e) : 100, this.tolerance = null != i ? 1 + Math.abs(i) : 1.1, this.delay = null != n ? n : 150, this.lastUpDeltas = function() {
                        for (var t = [], e = 1, i = 2 * this.stability; 1 <= i ? e <= i : i <= e; 1 <= i ? e++ : e--) t.push(null);
                        return t
                    }.call(this), this.lastDownDeltas = function() {
                        for (var t = [], e = 1, i = 2 * this.stability; 1 <= i ? e <= i : i <= e; 1 <= i ? e++ : e--) t.push(null);
                        return t
                    }.call(this), this.deltasTimestamp = function() {
                        for (var t = [], e = 1, i = 2 * this.stability; 1 <= i ? e <= i : i <= e; 1 <= i ? e++ : e--) t.push(null);
                        return t
                    }.call(this)
                }(null !== e ? e : this).Lethargy = (t.prototype.check = function(t) {
                    var e;
                    return null != (t = t.originalEvent || t).wheelDelta ? e = t.wheelDelta : null != t.deltaY ? e = -40 * t.deltaY : null == t.detail && 0 !== t.detail || (e = -40 * t.detail), this.deltasTimestamp.push(Date.now()), this.deltasTimestamp.shift(), 0 < e ? (this.lastUpDeltas.push(e), this.lastUpDeltas.shift(), this.isInertia(1)) : (this.lastDownDeltas.push(e), this.lastDownDeltas.shift(), this.isInertia(-1))
                }, t.prototype.isInertia = function(t) {
                    var e, i, n, s = -1 === t ? this.lastDownDeltas : this.lastUpDeltas;
                    return null === s[0] ? t : !(this.deltasTimestamp[2 * this.stability - 2] + this.delay > Date.now() && s[0] === s[2 * this.stability - 1]) && (i = s.slice(0, this.stability), e = s.slice(this.stability, 2 * this.stability), n = i.reduce(function(t, e) {
                        return t + e
                    }), s = e.reduce(function(t, e) {
                        return t + e
                    }), i = n / i.length, e = s / e.length, Math.abs(i) < Math.abs(e * this.tolerance) && this.sensitivity < Math.abs(e) && t)
                }, t.prototype.showLastUpDeltas = function() {
                    return this.lastUpDeltas
                }, t.prototype.showLastDownDeltas = function() {
                    return this.lastDownDeltas
                }, t)
            }.call(me)
        }),
        Ae = {
            hasWheelEvent: "onwheel" in document,
            hasMouseWheelEvent: "onmousewheel" in document,
            hasTouch: "ontouchstart" in window || window.TouchEvent || window.DocumentTouch && document instanceof DocumentTouch,
            hasTouchWin: navigator.msMaxTouchPoints && 1 < navigator.msMaxTouchPoints,
            hasPointer: !!window.navigator.msPointerEnabled,
            hasKeyDown: "onkeydown" in document,
            isFirefox: -1 < navigator.userAgent.indexOf("Firefox")
        },
        Oe = Object.prototype.toString,
        Le = Object.prototype.hasOwnProperty;
    var Me = Ce.Lethargy,
        Ie = "virtualscroll",
        Pe = Re,
        De = 37,
        je = 38,
        Be = 39,
        He = 40,
        _e = 32;

    function Re(t) {
        Se(this, "_onWheel", "_onMouseWheel", "_onTouchStart", "_onTouchMove", "_onKeyDown"), this.el = window, t && t.el && (this.el = t.el, delete t.el), this.options = Ee({
            mouseMultiplier: 1,
            touchMultiplier: 2,
            firefoxMultiplier: 15,
            keyStep: 120,
            preventTouch: !1,
            unpreventTouchClass: "vs-touchmove-allowed",
            limitInertia: !1,
            useKeyboard: !0,
            useTouch: !0
        }, t), this.options.limitInertia && (this._lethargy = new Me), this._emitter = new xe, this._event = {
            y: 0,
            x: 0,
            deltaX: 0,
            deltaY: 0
        }, this.touchStartX = null, this.touchStartY = null, this.bodyTouchAction = null, void 0 !== this.options.passive && (this.listenerOptions = {
            passive: this.options.passive
        })
    }

    function Fe(t, e, i) {
        return (1 - i) * t + i * e
    }

    function We(t) {
        var e = {};
        if (window.getComputedStyle) {
            var i = getComputedStyle(t),
                t = i.transform || i.webkitTransform || i.mozTransform,
                i = t.match(/^matrix3d\((.+)\)$/);
            return i ? (e.x = i ? parseFloat(i[1].split(", ")[12]) : 0, e.y = i ? parseFloat(i[1].split(", ")[13]) : 0) : (i = t.match(/^matrix\((.+)\)$/), e.x = i ? parseFloat(i[1].split(", ")[4]) : 0, e.y = i ? parseFloat(i[1].split(", ")[5]) : 0), e
        }
    }

    function qe(t) {
        for (var e = []; t && t !== document; t = t.parentNode) e.push(t);
        return e
    }
    Re.prototype._notify = function(t) {
        var e = this._event;
        e.x += e.deltaX, e.y += e.deltaY, this._emitter.emit(Ie, {
            x: e.x,
            y: e.y,
            deltaX: e.deltaX,
            deltaY: e.deltaY,
            originalEvent: t
        })
    }, Re.prototype._onWheel = function(t) {
        var e, i = this.options;
        this._lethargy && !1 === this._lethargy.check(t) || ((e = this._event).deltaX = t.wheelDeltaX || -1 * t.deltaX, e.deltaY = t.wheelDeltaY || -1 * t.deltaY, Ae.isFirefox && 1 == t.deltaMode && (e.deltaX *= i.firefoxMultiplier, e.deltaY *= i.firefoxMultiplier), e.deltaX *= i.mouseMultiplier, e.deltaY *= i.mouseMultiplier, this._notify(t))
    }, Re.prototype._onMouseWheel = function(t) {
        var e;
        this.options.limitInertia && !1 === this._lethargy.check(t) || ((e = this._event).deltaX = t.wheelDeltaX || 0, e.deltaY = t.wheelDeltaY || t.wheelDelta, this._notify(t))
    }, Re.prototype._onTouchStart = function(t) {
        t = t.targetTouches ? t.targetTouches[0] : t;
        this.touchStartX = t.pageX, this.touchStartY = t.pageY
    }, Re.prototype._onTouchMove = function(t) {
        var e = this.options;
        e.preventTouch && !t.target.classList.contains(e.unpreventTouchClass) && t.preventDefault();
        var i = this._event,
            n = t.targetTouches ? t.targetTouches[0] : t;
        i.deltaX = (n.pageX - this.touchStartX) * e.touchMultiplier, i.deltaY = (n.pageY - this.touchStartY) * e.touchMultiplier, this.touchStartX = n.pageX, this.touchStartY = n.pageY, this._notify(t)
    }, Re.prototype._onKeyDown = function(t) {
        var e = this._event;
        e.deltaX = e.deltaY = 0;
        var i = window.innerHeight - 40;
        switch (t.keyCode) {
            case De:
            case je:
                e.deltaY = this.options.keyStep;
                break;
            case Be:
            case He:
                e.deltaY = -this.options.keyStep;
                break;
            case t.shiftKey:
                e.deltaY = i;
                break;
            case _e:
                e.deltaY = -i;
                break;
            default:
                return
        }
        this._notify(t)
    }, Re.prototype._bind = function() {
        Ae.hasWheelEvent && this.el.addEventListener("wheel", this._onWheel, this.listenerOptions), Ae.hasMouseWheelEvent && this.el.addEventListener("mousewheel", this._onMouseWheel, this.listenerOptions), Ae.hasTouch && this.options.useTouch && (this.el.addEventListener("touchstart", this._onTouchStart, this.listenerOptions), this.el.addEventListener("touchmove", this._onTouchMove, this.listenerOptions)), Ae.hasPointer && Ae.hasTouchWin && (this.bodyTouchAction = document.body.style.msTouchAction, document.body.style.msTouchAction = "none", this.el.addEventListener("MSPointerDown", this._onTouchStart, !0), this.el.addEventListener("MSPointerMove", this._onTouchMove, !0)), Ae.hasKeyDown && this.options.useKeyboard && document.addEventListener("keydown", this._onKeyDown)
    }, Re.prototype._unbind = function() {
        Ae.hasWheelEvent && this.el.removeEventListener("wheel", this._onWheel), Ae.hasMouseWheelEvent && this.el.removeEventListener("mousewheel", this._onMouseWheel), Ae.hasTouch && (this.el.removeEventListener("touchstart", this._onTouchStart), this.el.removeEventListener("touchmove", this._onTouchMove)), Ae.hasPointer && Ae.hasTouchWin && (document.body.style.msTouchAction = this.bodyTouchAction, this.el.removeEventListener("MSPointerDown", this._onTouchStart, !0), this.el.removeEventListener("MSPointerMove", this._onTouchMove, !0)), Ae.hasKeyDown && this.options.useKeyboard && document.removeEventListener("keydown", this._onKeyDown)
    }, Re.prototype.on = function(t, e) {
        this._emitter.on(Ie, t, e);
        e = this._emitter.e;
        e && e[Ie] && 1 === e[Ie].length && this._bind()
    }, Re.prototype.off = function(t, e) {
        this._emitter.off(Ie, t, e);
        e = this._emitter.e;
        (!e[Ie] || e[Ie].length <= 0) && this._unbind()
    }, Re.prototype.reset = function() {
        var t = this._event;
        t.x = 0, t.y = 0
    }, Re.prototype.destroy = function() {
        this._emitter.off(), this._unbind()
    };
    var $e = 4,
        ze = 1e-7,
        Ye = 10,
        Ue = "function" == typeof Float32Array;

    function Ne(t, e) {
        return 1 - 3 * e + 3 * t
    }

    function Ve(t, e, i) {
        return ((Ne(e, i) * t + (3 * i - 6 * e)) * t + 3 * e) * t
    }

    function Xe(t, e, i) {
        return 3 * Ne(e, i) * t * t + 2 * (3 * i - 6 * e) * t + 3 * e
    }

    function Ke(t) {
        return t
    }

    function Ze(o, e, r, i) {
        if (!(0 <= o && o <= 1 && 0 <= r && r <= 1)) throw new Error("bezier x values must be in [0, 1] range");
        if (o === e && r === i) return Ke;
        for (var a = new(Ue ? Float32Array : Array)(11), t = 0; t < 11; ++t) a[t] = Ve(.1 * t, o, r);

        function n(t) {
            for (var e = 0, i = 1; 10 !== i && a[i] <= t; ++i) e += .1;
            var n = e + .1 * ((t - a[--i]) / (a[i + 1] - a[i])),
                s = Xe(n, o, r);
            return .001 <= s ? function(t, e, i, n) {
                for (var s = 0; s < $e; ++s) {
                    var o = Xe(e, i, n);
                    if (0 === o) return e;
                    e -= (Ve(e, i, n) - t) / o
                }
                return e
            }(t, n, o, r) : 0 === s ? n : function(t, e, i, n, s) {
                for (var o, r, a = 0; 0 < (o = Ve(r = e + (i - e) / 2, n, s) - t) ? i = r : e = r, Math.abs(o) > ze && ++a < Ye;);
                return r
            }(t, e, e + .1, o, r)
        }
        return function(t) {
            return 0 === t ? 0 : 1 === t ? 1 : Ve(n(t), e, i)
        }
    }
    var Ge = 38,
        Je = 40,
        Qe = 32,
        ti = 9,
        ei = 33,
        ii = 34,
        ni = 36,
        si = 35,
        oi = function() {
            ne(s, pe);
            var i = ae(s);

            function s() {
                var t, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                return Jt(this, s), history.scrollRestoration && (history.scrollRestoration = "manual"), window.scrollTo(0, 0), (t = i.call(this, e)).inertia && (t.lerp = .1 * t.inertia), t.isScrolling = !1, t.isDraggingScrollbar = !1, t.isTicking = !1, t.hasScrollTicking = !1, t.parallaxElements = {}, t.stop = !1, t.scrollbarContainer = e.scrollbarContainer, t.checkKey = t.checkKey.bind(re(t)), window.addEventListener("keydown", t.checkKey, !1), t
            }
            return te(s, [{
                key: "init",
                value: function() {
                    var e = this;
                    this.html.classList.add(this.smoothClass), this.html.setAttribute("data-".concat(this.name, "-direction"), this.direction), this.instance = ie({
                        delta: {
                            x: this.initPosition.x,
                            y: this.initPosition.y
                        },
                        scroll: {
                            x: this.initPosition.x,
                            y: this.initPosition.y
                        }
                    }, this.instance), this.vs = new Pe({
                        el: this.scrollFromAnywhere ? document : this.el,
                        mouseMultiplier: -1 < navigator.platform.indexOf("Win") ? 1 : .4,
                        firefoxMultiplier: this.firefoxMultiplier,
                        touchMultiplier: this.touchMultiplier,
                        useKeyboard: !1,
                        passive: !0
                    }), this.vs.on(function(t) {
                        e.stop || e.isDraggingScrollbar || requestAnimationFrame(function() {
                            e.updateDelta(t), e.isScrolling || e.startScrolling()
                        })
                    }), this.setScrollLimit(), this.initScrollBar(), this.addSections(), this.addElements(), this.checkScroll(!0), this.transformElements(!0, !0), le(se(s.prototype), "init", this).call(this)
                }
            }, {
                key: "setScrollLimit",
                value: function() {
                    if (this.instance.limit.y = this.el.offsetHeight - this.windowHeight, "horizontal" === this.direction) {
                        for (var t = 0, e = this.el.children, i = 0; i < e.length; i++) t += e[i].offsetWidth;
                        this.instance.limit.x = t - this.windowWidth
                    }
                }
            }, {
                key: "startScrolling",
                value: function() {
                    this.startScrollTs = Date.now(), this.isScrolling = !0, this.checkScroll(), this.html.classList.add(this.scrollingClass)
                }
            }, {
                key: "stopScrolling",
                value: function() {
                    cancelAnimationFrame(this.checkScrollRaf), this.startScrollTs = void 0, this.scrollToRaf && (cancelAnimationFrame(this.scrollToRaf), this.scrollToRaf = null), this.isScrolling = !1, this.instance.scroll.y = Math.round(this.instance.scroll.y), this.html.classList.remove(this.scrollingClass)
                }
            }, {
                key: "checkKey",
                value: function(t) {
                    var e = this;
                    if (this.stop) t.keyCode == ti && requestAnimationFrame(function() {
                        e.html.scrollTop = 0, document.body.scrollTop = 0, e.html.scrollLeft = 0, document.body.scrollLeft = 0
                    });
                    else {
                        switch (t.keyCode) {
                            case ti:
                                requestAnimationFrame(function() {
                                    e.html.scrollTop = 0, document.body.scrollTop = 0, e.html.scrollLeft = 0, document.body.scrollLeft = 0, e.scrollTo(document.activeElement, {
                                        offset: -window.innerHeight / 2
                                    })
                                });
                                break;
                            case Ge:
                                this.isActiveElementScrollSensitive() && (this.instance.delta[this.directionAxis] -= 240);
                                break;
                            case Je:
                                this.isActiveElementScrollSensitive() && (this.instance.delta[this.directionAxis] += 240);
                                break;
                            case ei:
                                this.instance.delta[this.directionAxis] -= window.innerHeight;
                                break;
                            case ii:
                                this.instance.delta[this.directionAxis] += window.innerHeight;
                                break;
                            case ni:
                                this.instance.delta[this.directionAxis] -= this.instance.limit[this.directionAxis];
                                break;
                            case si:
                                this.instance.delta[this.directionAxis] += this.instance.limit[this.directionAxis];
                                break;
                            case Qe:
                                this.isActiveElementScrollSensitive() && (t.shiftKey ? this.instance.delta[this.directionAxis] -= window.innerHeight : this.instance.delta[this.directionAxis] += window.innerHeight);
                                break;
                            default:
                                return
                        }
                        this.instance.delta[this.directionAxis] < 0 && (this.instance.delta[this.directionAxis] = 0), this.instance.delta[this.directionAxis] > this.instance.limit[this.directionAxis] && (this.instance.delta[this.directionAxis] = this.instance.limit[this.directionAxis]), this.stopScrolling(), this.isScrolling = !0, this.checkScroll(), this.html.classList.add(this.scrollingClass)
                    }
                }
            }, {
                key: "isActiveElementScrollSensitive",
                value: function() {
                    return !(document.activeElement instanceof HTMLInputElement || document.activeElement instanceof HTMLTextAreaElement || document.activeElement instanceof HTMLButtonElement || document.activeElement instanceof HTMLSelectElement)
                }
            }, {
                key: "checkScroll",
                value: function() {
                    var t, e, i = this,
                        n = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
                    (n || this.isScrolling || this.isDraggingScrollbar) && (this.hasScrollTicking || (this.checkScrollRaf = requestAnimationFrame(function() {
                        return i.checkScroll()
                    }), this.hasScrollTicking = !0), this.updateScroll(), e = Math.abs(this.instance.delta[this.directionAxis] - this.instance.scroll[this.directionAxis]), t = Date.now() - this.startScrollTs, !this.animatingScroll && 100 < t && (e < .5 && 0 != this.instance.delta[this.directionAxis] || e < .5 && 0 == this.instance.delta[this.directionAxis]) && this.stopScrolling(), Object.entries(this.sections).forEach(function(t) {
                        t = ce(t, 2);
                        t[0];
                        t = t[1];
                        t.persistent || i.instance.scroll[i.directionAxis] > t.offset[i.directionAxis] && i.instance.scroll[i.directionAxis] < t.limit[i.directionAxis] ? ("horizontal" === i.direction ? i.transform(t.el, -i.instance.scroll[i.directionAxis], 0) : i.transform(t.el, 0, -i.instance.scroll[i.directionAxis]), t.inView || (t.inView = !0, t.el.style.opacity = 1, t.el.style.pointerEvents = "all", t.el.setAttribute("data-".concat(i.name, "-section-inview"), ""))) : ((t.inView || n) && (t.inView = !1, t.el.style.opacity = 0, t.el.style.pointerEvents = "none", t.el.removeAttribute("data-".concat(i.name, "-section-inview"))), i.transform(t.el, 0, 0))
                    }), this.getDirection && this.addDirection(), this.getSpeed && (this.addSpeed(), this.speedTs = Date.now()), this.detectElements(), this.transformElements(), this.hasScrollbar && (e = this.instance.scroll[this.directionAxis] / this.instance.limit[this.directionAxis] * this.scrollBarLimit[this.directionAxis], "horizontal" === this.direction ? this.transform(this.scrollbarThumb, e, 0) : this.transform(this.scrollbarThumb, 0, e)), le(se(s.prototype), "checkScroll", this).call(this), this.hasScrollTicking = !1)
                }
            }, {
                key: "resize",
                value: function() {
                    this.windowHeight = window.innerHeight, this.windowWidth = window.innerWidth, this.checkContext(), this.windowMiddle = {
                        x: this.windowWidth / 2,
                        y: this.windowHeight / 2
                    }, this.update()
                }
            }, {
                key: "updateDelta",
                value: function(t) {
                    var e = (this[this.context] && this[this.context].gestureDirection ? this[this.context] : this).gestureDirection,
                        t = "both" === e ? t.deltaX + t.deltaY : "vertical" !== e && "horizontal" === e ? t.deltaX : t.deltaY;
                    this.instance.delta[this.directionAxis] -= t * this.multiplier, this.instance.delta[this.directionAxis] < 0 && (this.instance.delta[this.directionAxis] = 0), this.instance.delta[this.directionAxis] > this.instance.limit[this.directionAxis] && (this.instance.delta[this.directionAxis] = this.instance.limit[this.directionAxis])
                }
            }, {
                key: "updateScroll",
                value: function(t) {
                    this.isScrolling || this.isDraggingScrollbar ? this.instance.scroll[this.directionAxis] = Fe(this.instance.scroll[this.directionAxis], this.instance.delta[this.directionAxis], this.lerp) : this.instance.scroll[this.directionAxis] > this.instance.limit[this.directionAxis] ? this.setScroll(this.instance.scroll[this.directionAxis], this.instance.limit[this.directionAxis]) : this.instance.scroll.y < 0 ? this.setScroll(this.instance.scroll[this.directionAxis], 0) : this.setScroll(this.instance.scroll[this.directionAxis], this.instance.delta[this.directionAxis])
                }
            }, {
                key: "addDirection",
                value: function() {
                    this.instance.delta.y > this.instance.scroll.y ? "down" !== this.instance.direction && (this.instance.direction = "down") : this.instance.delta.y < this.instance.scroll.y && "up" !== this.instance.direction && (this.instance.direction = "up"), this.instance.delta.x > this.instance.scroll.x ? "right" !== this.instance.direction && (this.instance.direction = "right") : this.instance.delta.x < this.instance.scroll.x && "left" !== this.instance.direction && (this.instance.direction = "left")
                }
            }, {
                key: "addSpeed",
                value: function() {
                    this.instance.delta[this.directionAxis] != this.instance.scroll[this.directionAxis] ? this.instance.speed = (this.instance.delta[this.directionAxis] - this.instance.scroll[this.directionAxis]) / Math.max(1, Date.now() - this.speedTs) : this.instance.speed = 0
                }
            }, {
                key: "initScrollBar",
                value: function() {
                    if (this.scrollbar = document.createElement("span"), this.scrollbarThumb = document.createElement("span"), this.scrollbar.classList.add("".concat(this.scrollbarClass)), this.scrollbarThumb.classList.add("".concat(this.scrollbarClass, "_thumb")), this.scrollbar.append(this.scrollbarThumb), (this.scrollbarContainer || document.body).append(this.scrollbar), this.getScrollBar = this.getScrollBar.bind(this), this.releaseScrollBar = this.releaseScrollBar.bind(this), this.moveScrollBar = this.moveScrollBar.bind(this), this.scrollbarThumb.addEventListener("mousedown", this.getScrollBar), window.addEventListener("mouseup", this.releaseScrollBar), window.addEventListener("mousemove", this.moveScrollBar), this.hasScrollbar = !1, "horizontal" == this.direction) {
                        if (this.instance.limit.x + this.windowWidth <= this.windowWidth) return
                    } else if (this.instance.limit.y + this.windowHeight <= this.windowHeight) return;
                    this.hasScrollbar = !0, this.scrollbarBCR = this.scrollbar.getBoundingClientRect(), this.scrollbarHeight = this.scrollbarBCR.height, this.scrollbarWidth = this.scrollbarBCR.width, "horizontal" === this.direction ? this.scrollbarThumb.style.width = "".concat(this.scrollbarWidth * this.scrollbarWidth / (this.instance.limit.x + this.scrollbarWidth), "px") : this.scrollbarThumb.style.height = "".concat(this.scrollbarHeight * this.scrollbarHeight / (this.instance.limit.y + this.scrollbarHeight), "px"), this.scrollbarThumbBCR = this.scrollbarThumb.getBoundingClientRect(), this.scrollBarLimit = {
                        x: this.scrollbarWidth - this.scrollbarThumbBCR.width,
                        y: this.scrollbarHeight - this.scrollbarThumbBCR.height
                    }
                }
            }, {
                key: "reinitScrollBar",
                value: function() {
                    if (this.hasScrollbar = !1, "horizontal" == this.direction) {
                        if (this.instance.limit.x + this.windowWidth <= this.windowWidth) return
                    } else if (this.instance.limit.y + this.windowHeight <= this.windowHeight) return;
                    this.hasScrollbar = !0, this.scrollbarBCR = this.scrollbar.getBoundingClientRect(), this.scrollbarHeight = this.scrollbarBCR.height, this.scrollbarWidth = this.scrollbarBCR.width, "horizontal" === this.direction ? this.scrollbarThumb.style.width = "".concat(this.scrollbarWidth * this.scrollbarWidth / (this.instance.limit.x + this.scrollbarWidth), "px") : this.scrollbarThumb.style.height = "".concat(this.scrollbarHeight * this.scrollbarHeight / (this.instance.limit.y + this.scrollbarHeight), "px"), this.scrollbarThumbBCR = this.scrollbarThumb.getBoundingClientRect(), this.scrollBarLimit = {
                        x: this.scrollbarWidth - this.scrollbarThumbBCR.width,
                        y: this.scrollbarHeight - this.scrollbarThumbBCR.height
                    }
                }
            }, {
                key: "destroyScrollBar",
                value: function() {
                    this.scrollbarThumb.removeEventListener("mousedown", this.getScrollBar), window.removeEventListener("mouseup", this.releaseScrollBar), window.removeEventListener("mousemove", this.moveScrollBar), this.scrollbar.remove()
                }
            }, {
                key: "getScrollBar",
                value: function(t) {
                    this.isDraggingScrollbar = !0, this.checkScroll(), this.html.classList.remove(this.scrollingClass), this.html.classList.add(this.draggingClass)
                }
            }, {
                key: "releaseScrollBar",
                value: function(t) {
                    this.isDraggingScrollbar = !1, this.isScrolling && this.html.classList.add(this.scrollingClass), this.html.classList.remove(this.draggingClass)
                }
            }, {
                key: "moveScrollBar",
                value: function(i) {
                    var n = this;
                    this.isDraggingScrollbar && requestAnimationFrame(function() {
                        var t = 100 * (i.clientX - n.scrollbarBCR.left) / n.scrollbarWidth * n.instance.limit.x / 100,
                            e = 100 * (i.clientY - n.scrollbarBCR.top) / n.scrollbarHeight * n.instance.limit.y / 100;
                        0 < e && e < n.instance.limit.y && (n.instance.delta.y = e), 0 < t && t < n.instance.limit.x && (n.instance.delta.x = t)
                    })
                }
            }, {
                key: "addElements",
                value: function() {
                    var S = this;
                    this.els = {}, this.parallaxElements = {}, this.el.querySelectorAll("[data-".concat(this.name, "]")).forEach(function(t, e) {
                        var i, n = qe(t),
                            s = Object.entries(S.sections).map(function(t) {
                                t = ce(t, 2);
                                return t[0], t[1]
                            }).find(function(t) {
                                return n.includes(t.el)
                            }),
                            o = t.dataset[S.name + "Class"] || S.class,
                            r = "string" == typeof t.dataset[S.name + "Id"] ? t.dataset[S.name + "Id"] : "el" + e,
                            a = t.dataset[S.name + "Repeat"],
                            l = t.dataset[S.name + "Call"],
                            c = t.dataset[S.name + "Position"],
                            h = t.dataset[S.name + "Delay"],
                            u = t.dataset[S.name + "Direction"],
                            d = "string" == typeof t.dataset[S.name + "Sticky"],
                            f = !!t.dataset[S.name + "Speed"] && parseFloat(t.dataset[S.name + "Speed"]) / 10,
                            p = "string" == typeof t.dataset[S.name + "Offset"] ? t.dataset[S.name + "Offset"].split(",") : S.offset,
                            m = t.dataset[S.name + "Target"],
                            y = void 0 !== m ? document.querySelector("".concat(m)) : t,
                            v = y.getBoundingClientRect(),
                            g = null === s || s.inView ? (i = v.top + S.instance.scroll.y - We(y).y, v.left + S.instance.scroll.x - We(y).x) : (i = v.top - We(s.el).y - We(y).y, v.left - We(s.el).x - We(y).x),
                            w = i + y.offsetHeight,
                            b = g + y.offsetWidth,
                            k = {
                                x: (b - g) / 2 + g,
                                y: (w - i) / 2 + i
                            };
                        d && (m = (e = t.getBoundingClientRect()).top, e = {
                            x: (v = e.left) - g,
                            y: m - i
                        }, i += window.innerHeight, g += window.innerWidth, w = m + y.offsetHeight - t.offsetHeight - e[S.directionAxis], k = {
                            x: ((b = v + y.offsetWidth - t.offsetWidth - e[S.directionAxis]) - g) / 2 + g,
                            y: (w - i) / 2 + i
                        });
                        var a = "false" != a && (null != a || S.repeat),
                            E = [0, 0];
                        if (p)
                            if ("horizontal" === S.direction) {
                                for (var T = 0; T < p.length; T++) "string" == typeof p[T] ? p[T].includes("%") ? E[T] = parseInt(p[T].replace("%", "") * S.windowWidth / 100) : E[T] = parseInt(p[T]) : E[T] = p[T];
                                g += E[0], b -= E[1]
                            } else {
                                for (T = 0; T < p.length; T++) "string" == typeof p[T] ? p[T].includes("%") ? E[T] = parseInt(p[T].replace("%", "") * S.windowHeight / 100) : E[T] = parseInt(p[T]) : E[T] = p[T];
                                i += E[0], w -= E[1]
                            }
                        u = {
                            el: t,
                            id: r,
                            class: o,
                            section: s,
                            top: i,
                            middle: k,
                            bottom: w,
                            left: g,
                            right: b,
                            offset: p,
                            progress: 0,
                            repeat: a,
                            inView: !1,
                            call: l,
                            speed: f,
                            delay: h,
                            position: c,
                            target: y,
                            direction: u,
                            sticky: d
                        };
                        S.els[r] = u, t.classList.contains(o) && S.setInView(S.els[r], r), !1 === f && !d || (S.parallaxElements[r] = u)
                    })
                }
            }, {
                key: "addSections",
                value: function() {
                    var o = this;
                    this.sections = {};
                    var t = this.el.querySelectorAll("[data-".concat(this.name, "-section]"));
                    (t = 0 === t.length ? [this.el] : t).forEach(function(t, e) {
                        var i = "string" == typeof t.dataset[o.name + "Id"] ? t.dataset[o.name + "Id"] : "section" + e,
                            n = t.getBoundingClientRect(),
                            s = {
                                x: n.left - 1.5 * window.innerWidth - We(t).x,
                                y: n.top - 1.5 * window.innerHeight - We(t).y
                            },
                            e = {
                                x: s.x + n.width + 2 * window.innerWidth,
                                y: s.y + n.height + 2 * window.innerHeight
                            },
                            n = "string" == typeof t.dataset[o.name + "Persistent"];
                        t.setAttribute("data-scroll-section-id", i), o.sections[i] = {
                            el: t,
                            offset: s,
                            limit: e,
                            inView: !1,
                            persistent: n,
                            id: i
                        }
                    })
                }
            }, {
                key: "transform",
                value: function(t, e, i, n) {
                    var s, o, r;
                    s = n ? (r = Fe((o = We(t)).x, e, n), n = Fe(o.y, i, n), "matrix3d(1,0,0.00,0,0.00,1,0.00,0,0,0,1,0,".concat(r, ",").concat(n, ",0,1)")) : "matrix3d(1,0,0.00,0,0.00,1,0.00,0,0,0,1,0,".concat(e, ",").concat(i, ",0,1)"), t.style.webkitTransform = s, t.style.msTransform = s, t.style.transform = s
                }
            }, {
                key: "transformElements",
                value: function(n) {
                    var s = this,
                        o = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
                        r = this.instance.scroll.x + this.windowWidth,
                        a = this.instance.scroll.y + this.windowHeight,
                        l = {
                            x: this.instance.scroll.x + this.windowMiddle.x,
                            y: this.instance.scroll.y + this.windowMiddle.y
                        };
                    Object.entries(this.parallaxElements).forEach(function(t) {
                        t = ce(t, 2);
                        t[0];
                        var e = t[1],
                            i = n ? 0 : !1;
                        if (e.inView || o) switch (e.position) {
                            case "top":
                                i = s.instance.scroll[s.directionAxis] * -e.speed;
                                break;
                            case "elementTop":
                                i = (a - e.top) * -e.speed;
                                break;
                            case "bottom":
                                i = (s.instance.limit[s.directionAxis] - a + s.windowHeight) * e.speed;
                                break;
                            case "left":
                                i = s.instance.scroll[s.directionAxis] * -e.speed;
                                break;
                            case "elementLeft":
                                i = (r - e.left) * -e.speed;
                                break;
                            case "right":
                                i = (s.instance.limit[s.directionAxis] - r + s.windowHeight) * e.speed;
                                break;
                            default:
                                i = (l[s.directionAxis] - e.middle[s.directionAxis]) * -e.speed
                        }!1 !== (i = e.sticky ? e.inView ? "horizontal" === s.direction ? s.instance.scroll.x - e.left + window.innerWidth : s.instance.scroll.y - e.top + window.innerHeight : "horizontal" === s.direction ? s.instance.scroll.x < e.left - window.innerWidth && s.instance.scroll.x < e.left - window.innerWidth / 2 ? 0 : s.instance.scroll.x > e.right && s.instance.scroll.x > e.right + 100 && e.right - e.left + window.innerWidth : s.instance.scroll.y < e.top - window.innerHeight && s.instance.scroll.y < e.top - window.innerHeight / 2 ? 0 : s.instance.scroll.y > e.bottom && s.instance.scroll.y > e.bottom + 100 && e.bottom - e.top + window.innerHeight : i) && ("horizontal" === e.direction || "horizontal" === s.direction && "vertical" !== e.direction ? s.transform(e.el, i, 0, !n && e.delay) : s.transform(e.el, 0, i, !n && e.delay))
                    })
                }
            }, {
                key: "scrollTo",
                value: function(t) {
                    var i = this,
                        e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
                        n = parseInt(e.offset) || 0,
                        s = isNaN(parseInt(e.duration)) ? 1e3 : parseInt(e.duration),
                        o = e.easing || [.25, 0, .35, 1],
                        r = !!e.disableLerp,
                        a = e.callback || !1,
                        o = Ze.apply(void 0, he(o));
                    if ("string" == typeof t) {
                        if ("top" === t) t = 0;
                        else if ("bottom" === t) t = this.instance.limit.y;
                        else if ("left" === t) t = 0;
                        else if ("right" === t) t = this.instance.limit.x;
                        else if (!(t = document.querySelector(t))) return
                    } else if ("number" == typeof t) t = parseInt(t);
                    else if (!t || !t.tagName) return void console.warn("`target` parameter is not valid");
                    if ("number" != typeof t) {
                        if (!qe(t).includes(this.el)) return;
                        var l = t.getBoundingClientRect(),
                            c = l.top,
                            h = l.left,
                            e = qe(t).find(function(e) {
                                return Object.entries(i.sections).map(function(t) {
                                    t = ce(t, 2);
                                    return t[0], t[1]
                                }).find(function(t) {
                                    return t.el == e
                                })
                            }),
                            l = 0,
                            l = e ? We(e)[this.directionAxis] : -this.instance.scroll[this.directionAxis],
                            n = "horizontal" === this.direction ? h + n - l : c + n - l
                    } else n = t + n;
                    var u = parseFloat(this.instance.delta[this.directionAxis]),
                        d = Math.max(0, Math.min(n, this.instance.limit[this.directionAxis])) - u,
                        f = function(t) {
                            r ? "horizontal" === i.direction ? i.setScroll(u + d * t, i.instance.delta.y) : i.setScroll(i.instance.delta.x, u + d * t) : i.instance.delta[i.directionAxis] = u + d * t
                        };
                    this.animatingScroll = !0, this.stopScrolling(), this.startScrolling();
                    var p = Date.now();
                    (function t() {
                        var e = (Date.now() - p) / s;
                        1 < e ? (f(1), i.animatingScroll = !1, 0 == s && i.update(), a && a()) : (i.scrollToRaf = requestAnimationFrame(t), f(o(e)))
                    })()
                }
            }, {
                key: "update",
                value: function() {
                    this.setScrollLimit(), this.addSections(), this.addElements(), this.detectElements(), this.updateScroll(), this.transformElements(!0), this.reinitScrollBar(), this.checkScroll(!0)
                }
            }, {
                key: "startScroll",
                value: function() {
                    this.stop = !1
                }
            }, {
                key: "stopScroll",
                value: function() {
                    this.stop = !0
                }
            }, {
                key: "setScroll",
                value: function(t, e) {
                    this.instance = ie(ie({}, this.instance), {}, {
                        scroll: {
                            x: t,
                            y: e
                        },
                        delta: {
                            x: t,
                            y: e
                        },
                        speed: 0
                    })
                }
            }, {
                key: "destroy",
                value: function() {
                    le(se(s.prototype), "destroy", this).call(this), this.stopScrolling(), this.html.classList.remove(this.smoothClass), this.vs.destroy(), this.destroyScrollBar(), window.removeEventListener("keydown", this.checkKey, !1)
                }
            }]), s
        }(),
        ri = function() {
            function e() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                Jt(this, e), this.options = t, Object.assign(this, fe, t), this.smartphone = fe.smartphone, t.smartphone && Object.assign(this.smartphone, t.smartphone), this.tablet = fe.tablet, t.tablet && Object.assign(this.tablet, t.tablet), this.smooth || "horizontal" != this.direction || console.warn("🚨 `smooth:false` & `horizontal` direction are not yet compatible"), this.tablet.smooth || "horizontal" != this.tablet.direction || console.warn("🚨 `smooth:false` & `horizontal` direction are not yet compatible (tablet)"), this.smartphone.smooth || "horizontal" != this.smartphone.direction || console.warn("🚨 `smooth:false` & `horizontal` direction are not yet compatible (smartphone)"), this.init()
            }
            return te(e, [{
                key: "init",
                value: function() {
                    var t;
                    this.options.isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || "MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints || window.innerWidth < this.tablet.breakpoint, this.options.isTablet = this.options.isMobile && window.innerWidth >= this.tablet.breakpoint, this.smooth && !this.options.isMobile || this.tablet.smooth && this.options.isTablet || this.smartphone.smooth && this.options.isMobile && !this.options.isTablet ? this.scroll = new oi(this.options) : this.scroll = new ge(this.options), this.scroll.init(), window.location.hash && (t = window.location.hash.slice(1, window.location.hash.length), (t = document.getElementById(t)) && this.scroll.scrollTo(t))
                }
            }, {
                key: "update",
                value: function() {
                    this.scroll.update()
                }
            }, {
                key: "start",
                value: function() {
                    this.scroll.startScroll()
                }
            }, {
                key: "stop",
                value: function() {
                    this.scroll.stopScroll()
                }
            }, {
                key: "scrollTo",
                value: function(t, e) {
                    this.scroll.scrollTo(t, e)
                }
            }, {
                key: "setScroll",
                value: function(t, e) {
                    this.scroll.setScroll(t, e)
                }
            }, {
                key: "on",
                value: function(t, e) {
                    this.scroll.setEvents(t, e)
                }
            }, {
                key: "off",
                value: function(t, e) {
                    this.scroll.unsetEvents(t, e)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.scroll.destroy()
                }
            }]), e
        }(),
        ai = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), t = e.call(this, t), window.scrollObj = {
                    scroll: {
                        y: 0,
                        x: 0
                    },
                    limit: 0
                }, t.isTop = !0, t.lastY = 0, t
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var s = this;
                    document.documentElement.setAttribute("data-way", "down"), document.documentElement.classList.add("is-top"), this.isSmooth = !window.isIE, "false" == this.el.getAttribute("data-scroll-smooth") && (this.isSmooth = !1);
                    var t = window.location.href;
                    t.substr(t.lastIndexOf("/") + 1), "contribution-financiere" != t && "financial-contribution" != t || (this.isSmooth = !1), setTimeout(function() {
                        s.scroll = new ri({
                            el: s.el,
                            smooth: s.isSmooth,
                            class: "is-show",
                            getDirection: !0
                        }), s.scroll.on("call", function(t, e, i, n) {
                            s.call(t[0], {
                                way: e,
                                obj: i
                            }, t[1], t[2])
                        }), window.isIE || s.scroll.on("scroll", function(t) {
                            window.scrollObj = t, document.documentElement.setAttribute("data-way", t.direction), window.scrollObj.scroll.y < 40 ? s.isTop || (document.documentElement.classList.add("is-top"), s.isTop = !0) : s.isTop && (document.documentElement.classList.remove("is-top"), s.isTop = !1)
                        })
                    }, 500)
                }
            }, {
                key: "stop",
                value: function() {
                    this.scroll && this.scroll.stop && this.scroll.stop()
                }
            }, {
                key: "resume",
                value: function() {
                    this.scroll && this.scroll.start && this.scroll.start()
                }
            }, {
                key: "update",
                value: function() {
                    this.scroll && this.scroll.update && this.scroll.update()
                }
            }, {
                key: "scrollTo",
                value: function(t, e) {
                    this.scroll.scrollTo(t, -60)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.scroll.destroy(), S.classList.remove("is-scrolling-down", "has-small-mobile-header")
                }
            }]), i
        }(),
        li = "".concat(E, ".").concat("Share"),
        ci = {
            CLICK: "click.".concat(li)
        },
        hi = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    var e = this;
                    this.$el = $(this.el), this.$el.on(ci.CLICK, "[data-share-platform]", function(t) {
                        return e.share(t)
                    })
                }
            }, {
                key: "share",
                value: function(t) {
                    t.preventDefault();
                    var e = $(t.currentTarget),
                        t = e.data("share-platform"),
                        i = this.shareText,
                        n = this.$el.data("share-url");
                    switch (void 0 !== n && null !== typeof n || (n = window.location.href), console.log(n), t) {
                        case "facebook":
                            this.openWindow("https://facebook.com/sharer/sharer.php?u=" + n);
                            break;
                        case "linkedin":
                            this.openWindow("https://www.linkedin.com/shareArticle?url=" + n);
                            break;
                        case "twitter":
                            this.openWindow("https://twitter.com/share?url=" + n);
                            break;
                        case "pinterest":
                            this.openWindow("https://pinterest.com/pin/create/button/?url=" + n);
                            break;
                        case "mail":
                            var s = n;
                            this.openMail(i, s);
                            break;
                        case "copy":
                            this.copyUrl(n, e)
                    }
                }
            }, {
                key: "openWindow",
                value: function(t) {
                    window.open(t, "", "menubar=no, toolbar=no, resizable=yes, scrollbars=yes, height=500, width=600")
                }
            }, {
                key: "openMail",
                value: function(t, e) {
                    window.location = "mailto:?body=" + e
                }
            }, {
                key: "copyUrl",
                value: function(t) {
                    x.addClass("has-link-copied"), setTimeout(function() {
                        x.removeClass("has-link-copied")
                    }, 1500), window.copyToClipboard(t)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.$el.off(".".concat(li))
                }
            }]), i
        }(),
        ui = "resize",
        di = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.initSplit(), this.resizeBind = this.handleResize.bind(this), window.addEventListener(ui, this.resizeBind)
                }
            }, {
                key: "initSplit",
                value: function() {
                    this.splitLines = new SplitText(this.el, {
                        type: "lines, words"
                    })
                }
            }, {
                key: "revertSplit",
                value: function() {
                    this.splitLines && this.splitLines.revert && this.splitLines.revert()
                }
            }, {
                key: "handleResize",
                value: function() {
                    this.splitLines && (this.revertSplit(), this.initSplit())
                }
            }, {
                key: "destroy",
                value: function() {
                    window.removeEventListener(ui, this.resizeBind)
                }
            }]), i
        }();
    var fi = "lightbox-video-is-open",
        Ce = function() {
            p(s, h);
            var n = g(s);

            function s(t) {
                var e, i;
                return u(this, s), (e = n.call(this, t)).isPopup = e.el.getAttribute("data-popup"), e.video = {
                    iframe: (i = e.el.getAttribute("data-iframe"), (t = document.createElement("div")).innerHTML = i.trim(), t.firstChild),
                    provider: e.el.getAttribute("data-provider")
                }, e.events = {
                    click: "play"
                }, e
            }
            return f(s, [{
                key: "init",
                value: function() {
                    this.popup = document.getElementById("video-lightbox"), this.popupEmbed = document.getElementById("video-lightbox-embed"), this.closeButton = this.popup.querySelector(".js-close"), this.closeButtonBind = this.close.bind(this), this.closeButton.addEventListener("click", this.closeButtonBind)
                }
            }, {
                key: "play",
                value: function() {
                    var t;
                    this.isPopup && null != this.popup && null != this.popupEmbed && (document.documentElement.classList.add(fi), t = this.video.iframe.getAttribute("src"), "vimeo" === this.video.provider ? this.video.iframe.setAttribute("src", "".concat(t, "?autoplay=1")) : "youtube" === this.video.provider && this.video.iframe.setAttribute("src", "".concat(t, "?rel=0&autoplay=1")), this.popupEmbed.appendChild(this.video.iframe))
                }
            }, {
                key: "close",
                value: function() {
                    var t = this;
                    document.documentElement.classList.remove(fi), setTimeout(function() {
                        t.popupEmbed.innerHTML = ""
                    }, 1e3)
                }
            }, {
                key: "destroy",
                value: function() {
                    this.closeButton.removeEventListener("click", this.closeButtonBind)
                }
            }]), s
        }(),
        pi = ".js-input",
        E = function() {
            p(i, h);
            var e = g(i);

            function i(t) {
                return u(this, i), e.call(this, t)
            }
            return f(i, [{
                key: "init",
                value: function() {
                    this.defaultImage = this.getData("default-image"), this.initFilepond()
                }
            }, {
                key: "initFilepond",
                value: function() {
                    FilePond.registerPlugin(FilePondPluginFileEncode, FilePondPluginFileValidateType, FilePondPluginImageExifOrientation, FilePondPluginImagePreview, FilePondPluginImageCrop, FilePondPluginImageResize, FilePondPluginImageTransform), this.pond = FilePond.create(this.el.querySelector(pi), {
                        labelIdle: "Upload your picture <br> (300x300px)",
                        imageCropAspectRatio: "1:1",
                        imageResizeTargetWidth: 300,
                        imageResizeTargetHeight: 300,
                        stylePanelLayout: "compact circle",
                        styleLoadIndicatorPosition: "center bottom",
                        styleButtonRemoveItemPosition: "center bottom"
                    }), this.defaultImage && this.pond.addFile(this.defaultImage)
                }
            }, {
                key: "destroy",
                value: function() {
                    FilePond.destroy(this.el.querySelector(pi))
                }
            }]), i
        }(),
        Ce = Object.freeze({
            __proto__: null,
            accordion: L,
            backgroundprogress: M,
            carouselheader: P,
            carouselheadercount: j,
            carouselheadertext: H,
            carouselnumber: q,
            carouselwithpagination: U,
            chart: X,
            colorsetloop: et,
            consentform: it,
            cursorzone: lt,
            donation: ut,
            filters: dt,
            filterspatients: ft,
            form: vt,
            formcontact: gt,
            formdonation: wt,
            formprofileavatars: Tt,
            formprofilebanner: xt,
            formprofilecolors: Lt,
            formprofilefiles: It,
            formredirect: Pt,
            howtouse: _t,
            load: $t,
            lottieheader: Xt,
            menutoggler: Kt,
            popuptemp: Gt,
            scroll: ai,
            share: hi,
            splitline: di,
            videolightbox: Ce,
            widgetprofilepicture: E
        }),
        mi = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
    var yi, vi = (function(t) {
        var e, i;
        e = mi, i = function() {
            function f(t, e, i) {
                if (i) {
                    var n = document.createDocumentFragment(),
                        s = !e.hasAttribute("viewBox") && i.getAttribute("viewBox");
                    s && e.setAttribute("viewBox", s);
                    for (var o = i.cloneNode(!0); o.childNodes.length;) n.appendChild(o.firstChild);
                    t.appendChild(n)
                }
            }
            return function(t) {
                var a = Object(t),
                    t = window.top !== window.self,
                    l = "polyfill" in a ? a.polyfill : /\bTrident\/[567]\b|\bMSIE (?:9|10)\.0\b/.test(navigator.userAgent) || (navigator.userAgent.match(/\bEdge\/12\.(\d+)\b/) || [])[1] < 10547 || (navigator.userAgent.match(/\bAppleWebKit\/(\d+)\b/) || [])[1] < 537 || /\bEdge\/.(\d+)\b/.test(navigator.userAgent) && t,
                    c = {},
                    h = window.requestAnimationFrame || setTimeout,
                    u = document.getElementsByTagName("use"),
                    d = 0;
                l && function t() {
                    for (var e = 0; e < u.length;) {
                        var i, n = u[e],
                            s = n.parentNode,
                            o = function() {
                                for (var t = s;
                                    "svg" !== t.nodeName.toLowerCase() && (t = t.parentNode););
                                return t
                            }(),
                            r = n.getAttribute("xlink:href") || n.getAttribute("href");
                        !r && a.attributeName && (r = n.getAttribute(a.attributeName)), o && r ? l && (!a.validate || a.validate(r, o, n) ? (s.removeChild(n), n = (i = r.split("#")).shift(), r = i.join("#"), n.length ? ((i = c[n]) || ((i = c[n] = new XMLHttpRequest).open("GET", n), i.send(), i._embeds = []), i._embeds.push({
                            parent: s,
                            svg: o,
                            id: r
                        }), function(n) {
                            n.onreadystatechange = function() {
                                var i;
                                4 === n.readyState && ((i = n._cachedDocument) || ((i = n._cachedDocument = document.implementation.createHTMLDocument("")).body.innerHTML = n.responseText, n._cachedTarget = {}), n._embeds.splice(0).map(function(t) {
                                    var e = (e = n._cachedTarget[t.id]) || (n._cachedTarget[t.id] = i.getElementById(t.id));
                                    f(t.parent, t.svg, e)
                                }))
                            }, n.onreadystatechange()
                        }(i)) : f(s, o, document.getElementById(r))) : (++e, ++d)) : ++e
                    }(!u.length || 0 < u.length - d) && h(t, 67)
                }()
            }
        }, t.exports ? t.exports = i() : e.svg4everybody = i()
    }(yi = {
        exports: {}
    }), yi.exports);
    E = bowser.msie;
    (window.isIE = E) && document.documentElement.classList.add("is-ie");
    E = bowser.safari;
    window.isSafari = E, window.touch = !1;
    E = function t() {
        window.touch = !0, T.off("touchstart", t)
    };
    T.on("touchstart", E), window.isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || "MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints, (window.isMobile || window.isIE) && document.documentElement.classList.add("is-mobile"), window.isMobile || (window.cursor = {
        x: window.innerWidth / 2,
        y: window.innerHeight / 2
    }, T.on("mousemove", function(t) {
        window.cursor.x = t.pageX, window.cursor.y = t.pageY
    })), window.lottiePromises = [];
    Ce = new e({
        modules: Ce
    });
    Ce.init(Ce), vi()
}();